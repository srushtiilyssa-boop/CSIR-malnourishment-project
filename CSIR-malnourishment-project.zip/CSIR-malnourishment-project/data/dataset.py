"""
PyTorch Dataset for multimodal data (images + tabular).
"""
import pandas as pd
import numpy as np
from pathlib import Path
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

import torch
from torch.utils.data import Dataset


class MultimodalDataset(Dataset):
    """
    PyTorch Dataset for multimodal learning with images and tabular features.
    
    Args:
        df (pd.DataFrame): Input dataframe with image paths and labels.
        tabular_preprocessor: Fitted or unfitted scikit-learn preprocessor.
        image_root (Path or str): Root directory for image paths.
        tabular_features (list): Names of tabular feature columns.
        transform (callable, optional): Image transformation function.
        max_views (int): Maximum number of views to load per sample.
        fit_preprocessor (bool): Whether to fit the preprocessor on this data.
    """
    
    def __init__(self, df, tabular_preprocessor, image_root, tabular_features,
                 transform=None, max_views=4, fit_preprocessor=False):
        self.df = df.reset_index(drop=True)
        self.transform = transform
        self.max_views = max_views
        self.tabular_preprocessor = tabular_preprocessor
        self.image_root = Path(image_root)
        self.tabular_features = tabular_features
        self.valid_indices = []
        self.image_paths = []

        # Preprocess tabular features
        if fit_preprocessor:
            tabular_array = self.tabular_preprocessor.fit_transform(df[tabular_features])
        else:
            tabular_array = self.tabular_preprocessor.transform(df[tabular_features])
        self.tabular_features_array = tabular_array.astype(np.float32)

        # Find valid samples with images
        for idx, row in self.df.iterrows():
            paths = []
            for col in ['image_1', 'image_2', 'image_3', 'image_4', 'image_5']:
                if col in row and pd.notna(row[col]):
                    rel_path = str(row[col]).strip().replace('/', '\\')
                    full_path = self.image_root / rel_path
                    if full_path.exists():
                        try:
                            with Image.open(full_path) as img:
                                img.verify()
                            paths.append(full_path)
                            if len(paths) >= max_views:
                                break
                        except Exception:
                            continue
            if len(paths) > 0:
                self.valid_indices.append(idx)
                self.image_paths.append(paths)
        print(f"Dataset: {len(self.valid_indices)} valid samples out of {len(df)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        row_idx = self.valid_indices[idx]
        row = self.df.iloc[row_idx]
        paths = self.image_paths[idx]
        
        # Load images
        images = []
        for p in paths:
            try:
                img = Image.open(p).convert('RGB')
            except Exception:
                img = Image.new('RGB', (224, 224), (0, 0, 0))
            if self.transform:
                img = self.transform(img)
            images.append(img)
        
        # Pad missing views with zero tensors
        while len(images) < self.max_views:
            images.append(torch.zeros_like(images[0]))
        
        image_tensor = torch.stack(images, dim=0)
        
        # Create attention mask (1 for valid views, 0 for padded)
        mask = torch.zeros(self.max_views, dtype=torch.float32)
        mask[:len(paths)] = 1.0
        
        # Get tabular features and label
        tabular_tensor = torch.tensor(self.tabular_features_array[row_idx], dtype=torch.float32)
        label = torch.tensor(row['undernutrition_risk'], dtype=torch.float32)
        
        return image_tensor, mask, tabular_tensor, label
