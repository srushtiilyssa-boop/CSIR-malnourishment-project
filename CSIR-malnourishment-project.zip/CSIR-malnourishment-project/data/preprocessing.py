"""
Data preprocessing utilities for tabular features.
"""
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder


TABULAR_FEATURES = ['age_months', 'gender', 'head_circumference_cm', 'waist_circumference_cm']
NUMERIC_FEATURES = ['age_months', 'head_circumference_cm', 'waist_circumference_cm']
CATEGORICAL_FEATURES = ['gender']


def build_preprocessor():
    """
    Build a scikit-learn ColumnTransformer for leakage-controlled tabular preprocessing.
    
    Returns:
        ColumnTransformer: Preprocessor that handles numeric and categorical features.
    """
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, NUMERIC_FEATURES),
            ('cat', categorical_transformer, CATEGORICAL_FEATURES)
        ]
    )
    return preprocessor
