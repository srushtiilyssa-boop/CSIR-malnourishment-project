#!/usr/bin/env python3
"""
Phase 12b: Federated learning simulation with threshold tuning.
After training each combination, find optimal threshold on validation set (Youden's J)
and apply to test set for fair sensitivity/specificity reporting.
"""
import copy
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image, ImageFile
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import torchvision.transforms as transforms
from torchvision import models

ImageFile.LOAD_TRUNCATED_IMAGES = True

torch.manual_seed(42)
np.random.seed(42)

RAW_DIR = Path("data/raw")
IMAGE_SIZE = 224
MAX_VIEWS = 4
BATCH_SIZE = 8
LOCAL_EPOCHS = 1
COMM_ROUNDS = 10
LEARNING_RATE = 1e-4
IMG_EMBED_DIM = 256
TAB_EMBED_DIM = 128
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

TABULAR_FEATURES = ["age_months", "gender", "head_circumference_cm", "waist_circumference_cm"]
NUMERIC_FEATURES = ["age_months", "head_circumference_cm", "waist_circumference_cm"]
CATEGORICAL_FEATURES = ["gender"]


def build_preprocessor():
    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    return ColumnTransformer(transformers=[
        ("num", numeric_transformer, NUMERIC_FEATURES),
        ("cat", categorical_transformer, CATEGORICAL_FEATURES),
    ])


class MultimodalDataset(Dataset):
    def __init__(self, df, tabular_preprocessor, transform=None, max_views=4, fit_preprocessor=False):
        self.df = df.reset_index(drop=True)
        self.transform = transform
        self.max_views = max_views
        self.valid_indices = []
        self.image_paths = []

        if fit_preprocessor:
            tabular_array = tabular_preprocessor.fit_transform(df[TABULAR_FEATURES])
        else:
            tabular_array = tabular_preprocessor.transform(df[TABULAR_FEATURES])
        self.tabular_features = tabular_array.astype(np.float32)

        for idx, row in self.df.iterrows():
            paths = []
            for col in ["image_1", "image_2", "image_3", "image_4", "image_5"]:
                if col in row and pd.notna(row[col]):
                    rel_path = str(row[col]).strip().replace("/", "\\")
                    full_path = RAW_DIR / rel_path
                    if full_path.exists():
                        try:
                            with Image.open(full_path) as image:
                                image.verify()
                            paths.append(full_path)
                            if len(paths) >= max_views:
                                break
                        except Exception:
                            continue
            if paths:
                self.valid_indices.append(idx)
                self.image_paths.append(paths)
        print(f"Dataset: {len(self.valid_indices)} valid samples out of {len(df)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        row_idx = self.valid_indices[idx]
        row = self.df.iloc[row_idx]
        paths = self.image_paths[idx]
        images = []
        for path in paths:
            try:
                image = Image.open(path).convert("RGB")
            except Exception:
                image = Image.new("RGB", (IMAGE_SIZE, IMAGE_SIZE), (0, 0, 0))
            if self.transform:
                image = self.transform(image)
            images.append(image)
        while len(images) < self.max_views:
            images.append(torch.zeros_like(images[0]))
        image_tensor = torch.stack(images, dim=0)
        mask = torch.zeros(self.max_views, dtype=torch.float32)
        mask[:len(paths)] = 1.0
        tabular_tensor = torch.tensor(self.tabular_features[row_idx], dtype=torch.float32)
        label = torch.tensor(row["undernutrition_risk"], dtype=torch.float32)
        return image_tensor, mask, tabular_tensor, label


train_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomRotation(degrees=5),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])
eval_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])


class ImageEncoderResNet(nn.Module):
    def __init__(self, embed_dim=256):
        super().__init__()
        base = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
        self.features = nn.Sequential(*list(base.children())[:-1])
        self.projection = nn.Linear(512, embed_dim)

    def forward(self, x):
        x = self.features(x)
        return self.projection(torch.flatten(x, 1))


class TabularEncoder(nn.Module):
    def __init__(self, input_dim, embed_dim=128):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(input_dim, 128), nn.ReLU(), nn.Linear(128, embed_dim))

    def forward(self, x):
        return self.net(x)


class AttentionPooling(nn.Module):
    def __init__(self, embed_dim):
        super().__init__()
        self.attn = nn.Linear(embed_dim, 1)

    def forward(self, embeddings, mask):
        scores = self.attn(embeddings).squeeze(-1)
        scores = scores.masked_fill(mask == 0, -1e9)
        weights = F.softmax(scores, dim=1).unsqueeze(-1)
        return (embeddings * weights).sum(dim=1)


class CrossAttentionMultimodal(nn.Module):
    def __init__(self, tab_input_dim):
        super().__init__()
        self.image_encoder = ImageEncoderResNet(IMG_EMBED_DIM)
        self.pool = AttentionPooling(IMG_EMBED_DIM)
        self.tabular_encoder = TabularEncoder(tab_input_dim, TAB_EMBED_DIM)
        self.img_proj = nn.Linear(IMG_EMBED_DIM, 128)
        self.tab_proj = nn.Linear(TAB_EMBED_DIM, 128)
        self.attn = nn.MultiheadAttention(embed_dim=128, num_heads=4, batch_first=True)
        self.norm = nn.LayerNorm(128)
        self.fusion = nn.Sequential(nn.Linear(128 + TAB_EMBED_DIM, 128), nn.ReLU(), nn.Linear(128, 1))

    def forward(self, images, mask, tabular):
        batch_size, view_count, channels, height, width = images.shape
        flat = images.view(batch_size * view_count, channels, height, width)
        embeds = self.image_encoder(flat).view(batch_size, view_count, -1)
        img_embed = self.pool(embeds, mask)
        tab_embed = self.tabular_encoder(tabular)
        query = self.img_proj(img_embed).unsqueeze(1)
        key = self.tab_proj(tab_embed).unsqueeze(1)
        attn_out, _ = self.attn(query, key, key)
        attn_out = self.norm(attn_out.squeeze(1))
        return self.fusion(torch.cat([attn_out, tab_embed], dim=1))


def partition_iid(df, num_clients):
    shuffled_indices = np.random.permutation(len(df))
    splits = np.array_split(shuffled_indices, num_clients)
    return [df.iloc[split].reset_index(drop=True) for split in splits]


def partition_non_iid(df, num_clients, alpha=0.5):
    labels = df["undernutrition_risk"].values
    client_indices = [[] for _ in range(num_clients)]
    for label in np.unique(labels):
        label_indices = np.where(labels == label)[0]
        np.random.shuffle(label_indices)
        proportions = np.random.dirichlet(np.repeat(alpha, num_clients))
        counts = (proportions * len(label_indices)).astype(int)
        counts[-1] = len(label_indices) - counts[:-1].sum()
        start = 0
        for client_id, count in enumerate(counts):
            client_indices[client_id].extend(label_indices[start:start + count])
            start += count
    return [df.iloc[indices].reset_index(drop=True) for indices in client_indices]


def compute_metrics(y_true, y_pred, y_proba):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "sensitivity": recall_score(y_true, y_pred, zero_division=0),
        "specificity": tn / (tn + fp) if (tn + fp) else 0.0,
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, y_proba),
        "pr_auc": average_precision_score(y_true, y_proba),
        "confusion_matrix": [[tn, fp], [fn, tp]],
    }


def predict_proba(model, loader):
    model.eval()
    all_probs, all_labels = [], []
    with torch.no_grad():
        for images, mask, tabular, labels in loader:
            images = images.to(DEVICE)
            mask = mask.to(DEVICE)
            tabular = tabular.to(DEVICE)
            logits = model(images, mask, tabular)
            all_probs.extend(torch.sigmoid(logits).cpu().numpy().flatten())
            all_labels.extend(labels.numpy())
    return np.array(all_probs), np.array(all_labels)


def find_optimal_threshold(labels, probabilities):
    false_positive_rate, true_positive_rate, thresholds = roc_curve(labels, probabilities)
    return float(thresholds[np.argmax(true_positive_rate - false_positive_rate)])


def main():
    train_df = pd.read_csv("data/splits/train.csv")
    val_df = pd.read_csv("data/splits/validation.csv")
    test_df = pd.read_csv("data/splits/test.csv")

    preprocessor = build_preprocessor()
    preprocessor.fit(train_df[TABULAR_FEATURES])
    val_dataset = MultimodalDataset(val_df, preprocessor, eval_transform, MAX_VIEWS)
    test_dataset = MultimodalDataset(test_df, preprocessor, eval_transform, MAX_VIEWS)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    tab_input_dim = preprocessor.transform(train_df[TABULAR_FEATURES]).shape[1]
    print(f"Tabular input dimension: {tab_input_dim}")

    num_clients = 5
    all_results = []
    for distribution in ["iid", "non_iid"]:
        client_dfs = (partition_iid(train_df, num_clients) if distribution == "iid"
                      else partition_non_iid(train_df, num_clients, alpha=0.5))
        print(f"\n=== Distribution: {distribution} ===")
        for client_id, client_df in enumerate(client_dfs):
            print(f"Client {client_id}: {len(client_df)} samples, risk count={client_df['undernutrition_risk'].sum()}")

        client_datasets = [MultimodalDataset(client_df, preprocessor, train_transform, MAX_VIEWS)
                           for client_df in client_dfs]
        client_loaders = [DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
                          for dataset in client_datasets]
        client_sizes = [len(dataset) for dataset in client_datasets]
        total_size = sum(client_sizes)
        labels = train_df["undernutrition_risk"].values
        positive_count = np.sum(labels == 1)
        negative_count = np.sum(labels == 0)
        pos_weight = negative_count / positive_count if positive_count else 1.0

        for method in ["FedAvg", "FedProx"]:
            print(f"  Training with {method}...")
            global_model = CrossAttentionMultimodal(tab_input_dim).to(DEVICE)
            global_weights = copy.deepcopy(global_model.state_dict())
            val_roc_history, test_roc_history = [], []

            for round_idx in range(1, COMM_ROUNDS + 1):
                client_updates, client_weights = [], []
                for client_id, loader in enumerate(client_loaders):
                    local_model = CrossAttentionMultimodal(tab_input_dim).to(DEVICE)
                    local_model.load_state_dict(global_weights)
                    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE)
                    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([pos_weight], device=DEVICE))
                    local_model.train()
                    for _ in range(LOCAL_EPOCHS):
                        for images, mask, tabular, labels_batch in loader:
                            images = images.to(DEVICE)
                            mask = mask.to(DEVICE)
                            tabular = tabular.to(DEVICE)
                            labels_batch = labels_batch.to(DEVICE).unsqueeze(1)
                            optimizer.zero_grad()
                            loss = criterion(local_model(images, mask, tabular), labels_batch)
                            if method == "FedProx":
                                prox_term = sum(torch.norm(local - global_param) ** 2
                                                for local, global_param in zip(local_model.parameters(), global_model.parameters()))
                                loss = loss + 0.5 * 0.1 * prox_term
                            loss.backward()
                            optimizer.step()
                    client_updates.append(copy.deepcopy(local_model.state_dict()))
                    client_weights.append(client_sizes[client_id] / total_size)

                aggregated = copy.deepcopy(global_weights)
                for key in aggregated:
                    if aggregated[key].dtype in [torch.float32, torch.float64]:
                        aggregated[key] = torch.zeros_like(aggregated[key])
                        for update, weight in zip(client_updates, client_weights):
                            aggregated[key] += weight * update[key]
                global_weights = aggregated
                global_model.load_state_dict(global_weights)

                val_probs, val_labels = predict_proba(global_model, val_loader)
                test_probs, test_labels = predict_proba(global_model, test_loader)
                val_roc_history.append(roc_auc_score(val_labels, val_probs))
                test_roc_history.append(roc_auc_score(test_labels, test_probs))
                print(f"    Round {round_idx}/{COMM_ROUNDS} | Val ROC-AUC: {val_roc_history[-1]:.4f} | Test ROC-AUC: {test_roc_history[-1]:.4f}")

            val_probs, val_labels = predict_proba(global_model, val_loader)
            test_probs, test_labels = predict_proba(global_model, test_loader)
            threshold = find_optimal_threshold(val_labels, val_probs)
            tuned_metrics = compute_metrics(test_labels, (test_probs >= threshold).astype(int), test_probs)
            default_metrics = compute_metrics(test_labels, (test_probs >= 0.5).astype(int), test_probs)
            print(f"    Optimal threshold (Youden) on validation: {threshold:.4f}")

            result = {
                "distribution": distribution,
                "method": method,
                "threshold": threshold,
                "test_roc_auc": tuned_metrics["roc_auc"],
                "test_sensitivity": tuned_metrics["sensitivity"],
                "test_specificity": tuned_metrics["specificity"],
                "test_f1": tuned_metrics["f1"],
                "test_balanced_accuracy": tuned_metrics["balanced_accuracy"],
                "test_accuracy": tuned_metrics["accuracy"],
                "default_0.5_sensitivity": default_metrics["sensitivity"],
                "default_0.5_specificity": default_metrics["specificity"],
            }
            all_results.append(result)
            pd.DataFrame({"label": val_labels, "prob": val_probs}).to_csv(
                f"results/{distribution}_{method}_val_probs_tuned.csv", index=False)
            pd.DataFrame({"label": test_labels, "prob": test_probs}).to_csv(
                f"results/{distribution}_{method}_test_probs_tuned.csv", index=False)

    results_df = pd.DataFrame(all_results)
    results_df.to_csv("results/federated_results_tuned.csv", index=False)
    print("\nFederated results (tuned thresholds) saved to results/federated_results_tuned.csv")
    print(results_df[["distribution", "method", "threshold", "test_roc_auc",
                      "test_sensitivity", "test_specificity", "test_f1"]].to_string(index=False))

    plt.figure(figsize=(8, 5))
    for result in all_results:
        label = f"{result['distribution']} - {result['method']}"
        # Histories are recomputed only for reporting in the original script; the tuned
        # result table and probability files are the primary outputs of this phase.
        del label
    plt.close()


if __name__ == "__main__":
    main()
