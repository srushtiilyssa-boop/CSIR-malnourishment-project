#!/usr/bin/env python3
"""
Phase 2: Construct child-level multimodal dataset from metadata and image mapping.
Output: data/processed/child_multimodal_dataset.csv
"""
import pandas as pd
from pathlib import Path

def main():
    # Load metadata
    meta_path = Path("data/mappings/metadata_inspected.csv")
    if not meta_path.exists():
        raise FileNotFoundError("Run Phase 1 first: metadata_inspected.csv missing.")
    metadata = pd.read_csv(meta_path)

    # Standardize columns
    rename_map = {
        'ID': 'child_id',
        'id': 'child_id',
        'Gender': 'gender',
        'Sex': 'gender',
        'Age': 'age_months',
        'AgeMonths': 'age_months',
        'age': 'age_months',
        'age in months': 'age_months',
        'Height': 'height_cm',
        'height': 'height_cm',
        'height in cm': 'height_cm',
        'Weight': 'weight_g',
        'weight': 'weight_g',
        'weight in grams': 'weight_g',
        'HeadCirc': 'head_circumference_cm',
        'head_circumference': 'head_circumference_cm',
        'head circumference in cm': 'head_circumference_cm',
        'WaistCirc': 'waist_circumference_cm',
        'waist_circumference': 'waist_circumference_cm',
        'waistline in cm': 'waist_circumference_cm'
    }
    metadata.rename(columns=rename_map, inplace=True)

    # Ensure required columns exist
    required = ['child_id', 'gender', 'age_months', 'height_cm', 'weight_g',
                'head_circumference_cm', 'waist_circumference_cm']
    missing = [c for c in required if c not in metadata.columns]
    if missing:
        print(f"WARNING: Missing columns in metadata: {missing}")
        for c in missing:
            metadata[c] = None

    # Normalize child_id to string
    metadata['child_id'] = metadata['child_id'].astype(str).str.strip()
    def norm_id(x):
        try:
            return str(int(float(x)))
        except:
            return x
    metadata['child_id_norm'] = metadata['child_id'].apply(norm_id)

    # Load image mapping
    mapping_path = Path("data/mappings/child_image_mapping.csv")
    if not mapping_path.exists():
        raise FileNotFoundError("Run Phase 1 mapping first: child_image_mapping.csv missing.")
    mapping = pd.read_csv(mapping_path)
    mapping['child_id_norm'] = mapping['child_id'].astype(str).apply(norm_id)

    # Pivot image mapping to wide format
    mapping = mapping.sort_values(['child_id_norm', 'view_id'])
    image_wide = mapping.pivot(index='child_id_norm', columns='view_id', values='image_path')
    image_wide.columns = [f"image_{int(col.split('_')[1])}" for col in image_wide.columns]
    image_wide = image_wide.reset_index()

    # Merge metadata with images
    combined = pd.merge(metadata, image_wide, on='child_id_norm', how='left')

    # Reorder columns
    base_cols = ['child_id', 'gender', 'age_months', 'height_cm', 'weight_g',
                 'head_circumference_cm', 'waist_circumference_cm']
    image_cols = sorted([c for c in combined.columns if c.startswith('image_')],
                        key=lambda x: int(x.split('_')[1]))
    final_cols = base_cols + image_cols
    final_cols = [c for c in final_cols if c in combined.columns]
    combined = combined[final_cols]

    # Drop rows with missing child_id
    combined = combined.dropna(subset=['child_id'])

    # Save
    out_path = Path("data/processed/child_multimodal_dataset.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    combined.to_csv(out_path, index=False)
    print(f"Child-level multimodal dataset saved to {out_path}")
    print(f"Total children: {len(combined)}")
    print(f"Columns: {list(combined.columns)}")
    print("\nFirst 5 rows:")
    print(combined.head())

if __name__ == "__main__":
    main()
