#!/usr/bin/env python3
"""
Phase 4: Create child-level stratified train/validation/test split.
Splits the merged child-level dataset 70/15/15, stratified by undernutrition_risk.
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from pathlib import Path

def main():
    # Load data
    multimodal_path = Path("data/processed/child_multimodal_dataset.csv")
    targets_path = Path("data/processed/nutritional_targets.csv")
    if not multimodal_path.exists() or not targets_path.exists():
        raise FileNotFoundError("Required input files missing. Run earlier phases first.")

    multimodal = pd.read_csv(multimodal_path)
    targets = pd.read_csv(targets_path)

    # Merge on child_id (both are child-level)
    df = pd.merge(multimodal, targets[['child_id', 'undernutrition_risk']],
                  on='child_id', how='inner')
    print(f"Merged dataset shape: {df.shape}")

    # Check for duplicate child_ids
    if df['child_id'].duplicated().any():
        print("WARNING: Duplicate child_id found in merged data.")
        df = df.drop_duplicates(subset='child_id', keep='first')

    # Stratified split: first split off 15% test, then 15% validation from remaining
    train_val, test = train_test_split(
        df,
        test_size=0.15,
        random_state=42,
        stratify=df['undernutrition_risk']
    )
    train, val = train_test_split(
        train_val,
        test_size=0.15 / 0.85,  # yields 15% of original as validation
        random_state=42,
        stratify=train_val['undernutrition_risk']
    )

    # Save splits
    out_dir = Path("data/splits")
    out_dir.mkdir(parents=True, exist_ok=True)
    train.to_csv(out_dir / "train.csv", index=False)
    val.to_csv(out_dir / "validation.csv", index=False)
    test.to_csv(out_dir / "test.csv", index=False)

    # Create summary report
    def class_counts(subset):
        return subset['undernutrition_risk'].value_counts().to_dict()

    summary = []
    summary.append("CHILD-LEVEL SPLIT SUMMARY")
    summary.append("=" * 60)
    summary.append(f"Total children: {len(df)}")
    summary.append(f"Train size: {len(train)} (risk: {class_counts(train).get(1, 0)})")
    summary.append(f"Validation size: {len(val)} (risk: {class_counts(val).get(1, 0)})")
    summary.append(f"Test size: {len(test)} (risk: {class_counts(test).get(1, 0)})")
    summary.append(f"Train risk proportion: {train['undernutrition_risk'].mean():.4f}")
    summary.append(f"Val risk proportion: {val['undernutrition_risk'].mean():.4f}")
    summary.append(f"Test risk proportion: {test['undernutrition_risk'].mean():.4f}")
    summary.append(f"Random seed: 42")
    summary.append("Stratification: undernutrition_risk")
    summary.append("Splits saved to data/splits/")

    with open(out_dir / "split_summary.txt", 'w') as f:
        f.write('\n'.join(summary))

    print("\n".join(summary))

    # Quick sanity check: no child_id appears in multiple splits
    train_ids = set(train['child_id'])
    val_ids = set(val['child_id'])
    test_ids = set(test['child_id'])
    overlap = (train_ids & val_ids) | (train_ids & test_ids) | (val_ids & test_ids)
    if overlap:
        print(f"ERROR: Overlap detected! {len(overlap)} child IDs appear in multiple splits.")
    else:
        print("Sanity check passed: no child ID appears in multiple splits.")

if __name__ == "__main__":
    main()
