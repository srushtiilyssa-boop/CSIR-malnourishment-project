#!/usr/bin/env python3
"""
Phase 7: Multi-view image model (shared encoder + mean pooling)
Uses MobileNetV3-Small as shared encoder, aggregates up to 4 views via mean.
"""
import pandas as pd
import numpy as np
from pathlib import Path
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision import models
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, average_precision_score, confusion_matrix,
    classification_report
)
import copy

# Reproducibility
torch.manual_seed(42)
np.random.seed(42)

RAW_DIR = Path("data/raw")
IMAGE_SIZE = 224
MAX_VIEWS = 4
BATCH_SIZE = 8
EPOCHS = 20
LEARNING_RATE = 1e-4
EMBED_DIM = 128
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

# ---------------------------------------------------------------------
# Dataset class
# ---------------------------------------------------------------------
class MultiViewDataset(Dataset):
    def __init__(self, df, transform=None, max_views=4):
        self.df = df.reset_index(drop=True)
        self.transform = transform
        self.max_views = max_views
        self.valid_indices = []
        self.image_paths = []   # list of list of paths per sample
        for idx, row in self.df.iterrows():
            paths = []
            for col in ['image_1', 'image_2', 'image_3', 'image_4', 'image_5']:
                if col in row and pd.notna(row[col]):
                    rel_path = str(row[col]).strip().replace('/', '\\')
                    full_path = RAW_DIR / rel_path
                    if full_path.exists():
                        try:
                            with Image.open(full_path) as img:
                                img.verify()
                            paths.append(full_path)
                            if len(paths) >= max_views:
                                break
                        except Exception:
                            continue
            if len(paths) > 0:
                self.valid_indices.append(idx)
                self.image_paths.append(paths)
        print(f"Dataset: {len(self.valid_indices)} valid samples out of {len(df)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        row_idx = self.valid_indices[idx]
        row = self.df.iloc[row_idx]
        paths = self.image_paths[idx]
        images = []
        for p in paths:
            try:
                img = Image.open(p).convert('RGB')
            except Exception:
                img = Image.new('RGB', (IMAGE_SIZE, IMAGE_SIZE), (0, 0, 0))
            if self.transform:
                img = self.transform(img)
            images.append(img)
        # Pad to max_views
        while len(images) < self.max_views:
            images.append(torch.zeros_like(images[0]))
        image_tensor = torch.stack(images, dim=0)  # (max_views, 3, H, W)
        mask = torch.zeros(self.max_views, dtype=torch.float32)
        mask[:len(paths)] = 1.0
        label = torch.tensor(row['undernutrition_risk'], dtype=torch.float32)
        return image_tensor, mask, label

# ---------------------------------------------------------------------
# Transforms
# ---------------------------------------------------------------------
train_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomRotation(degrees=5),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
eval_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# ---------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------
class SharedEncoder(nn.Module):
    def __init__(self, embed_dim=128):
        super().__init__()
        base = models.mobilenet_v3_small(weights=models.MobileNet_V3_Small_Weights.IMAGENET1K_V1)
        self.features = base.features
        self.avgpool = base.avgpool
        self.projection = nn.Linear(576, embed_dim)  # MobileNetV3-Small last conv output channels = 576
    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.projection(x)
        return x

class MultiViewMeanPoolModel(nn.Module):
    def __init__(self, embed_dim=128):
        super().__init__()
        self.encoder = SharedEncoder(embed_dim)
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )
    def forward(self, images, mask):
        B, V, C, H, W = images.shape
        flat_images = images.view(B * V, C, H, W)
        flat_embeddings = self.encoder(flat_images)   # (B*V, embed_dim)
        embeddings = flat_embeddings.view(B, V, -1)     # (B, V, embed_dim)
        mask_expanded = mask.unsqueeze(-1)             # (B, V, 1)
        sum_embeddings = (embeddings * mask_expanded).sum(dim=1)  # (B, embed_dim)
        valid_counts = mask_expanded.sum(dim=1).clamp(min=1)      # (B, 1)
        pooled = sum_embeddings / valid_counts         # (B, embed_dim)
        logits = self.classifier(pooled)               # (B, 1)
        return logits

# ---------------------------------------------------------------------
# Training & evaluation
# ---------------------------------------------------------------------
def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    running_loss = 0.0
    for images, mask, labels in loader:
        images, mask, labels = images.to(device), mask.to(device), labels.to(device).unsqueeze(1)
        optimizer.zero_grad()
        logits = model(images, mask)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * images.size(0)
    return running_loss / len(loader.dataset)


def evaluate(model, loader, device):
    model.eval()
    all_preds = []
    all_labels = []
    all_probs = []
    with torch.no_grad():
        for images, mask, labels in loader:
            images, mask, labels = images.to(device), mask.to(device), labels.to(device)
            logits = model(images, mask)
            probs = torch.sigmoid(logits).cpu().numpy().flatten()
            preds = (probs >= 0.5).astype(int)
            all_probs.extend(probs)
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())
    metrics = compute_metrics(all_labels, all_preds, all_probs)
    metrics['y_true'] = all_labels
    metrics['y_pred'] = all_preds
    metrics['y_proba'] = all_probs
    return metrics


def compute_metrics(y_true, y_pred, y_proba):
    acc = accuracy_score(y_true, y_pred)
    bal_acc = balanced_accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    macro_f1 = f1_score(y_true, y_pred, average='macro', zero_division=0)
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    roc_auc = roc_auc_score(y_true, y_proba)
    pr_auc = average_precision_score(y_true, y_proba)
    return {
        'accuracy': acc,
        'balanced_accuracy': bal_acc,
        'precision': prec,
        'recall': rec,
        'f1': f1,
        'macro_f1': macro_f1,
        'sensitivity': sensitivity,
        'specificity': specificity,
        'roc_auc': roc_auc,
        'pr_auc': pr_auc,
        'confusion_matrix': cm.tolist()
    }


def main():
    train_df = pd.read_csv(Path("data/splits/train.csv"))
    val_df = pd.read_csv(Path("data/splits/validation.csv"))
    test_df = pd.read_csv(Path("data/splits/test.csv"))

    train_dataset = MultiViewDataset(train_df, transform=train_transform, max_views=MAX_VIEWS)
    val_dataset = MultiViewDataset(val_df, transform=eval_transform, max_views=MAX_VIEWS)
    test_dataset = MultiViewDataset(test_df, transform=eval_transform, max_views=MAX_VIEWS)

    y_train = train_df.loc[train_dataset.valid_indices, 'undernutrition_risk'].values
    pos_count = np.sum(y_train == 1)
    neg_count = np.sum(y_train == 0)
    pos_weight = neg_count / pos_count if pos_count > 0 else 1.0
    pos_weight_tensor = torch.tensor([pos_weight]).to(DEVICE)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight_tensor)

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

    model = MultiViewMeanPoolModel(embed_dim=EMBED_DIM).to(DEVICE)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    best_val_roc = -1
    best_model_state = None
    patience = 5
    epochs_no_improve = 0

    print("Starting training...")
    for epoch in range(1, EPOCHS+1):
        train_loss = train_one_epoch(model, train_loader, optimizer, criterion, DEVICE)
        val_metrics = evaluate(model, val_loader, DEVICE)
        print(f"Epoch {epoch}/{EPOCHS} | Train Loss: {train_loss:.4f} | Val ROC-AUC: {val_metrics['roc_auc']:.4f} | Val Sens: {val_metrics['sensitivity']:.4f}")

        if val_metrics['roc_auc'] > best_val_roc:
            best_val_roc = val_metrics['roc_auc']
            best_model_state = copy.deepcopy(model.state_dict())
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= patience:
                print(f"Early stopping triggered after {epoch} epochs.")
                break

    if best_model_state:
        model.load_state_dict(best_model_state)

    val_metrics = evaluate(model, val_loader, DEVICE)
    test_metrics = evaluate(model, test_loader, DEVICE)

    print("\nValidation metrics:")
    for k, v in val_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            print(f"  {k}: {v}")
    print(f"  Confusion matrix:\n  {np.array(val_metrics['confusion_matrix'])}")
    print("\nTest metrics:")
    for k, v in test_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            print(f"  {k}: {v}")
    print(f"  Confusion matrix:\n  {np.array(test_metrics['confusion_matrix'])}")

    results = {
        'model': 'MobileNetV3-Small multi-view mean pooling',
        'feature_set': 'image_only',
        'val_accuracy': val_metrics['accuracy'],
        'val_balanced_accuracy': val_metrics['balanced_accuracy'],
        'val_precision': val_metrics['precision'],
        'val_recall': val_metrics['recall'],
        'val_f1': val_metrics['f1'],
        'val_macro_f1': val_metrics['macro_f1'],
        'val_sensitivity': val_metrics['sensitivity'],
        'val_specificity': val_metrics['specificity'],
        'val_roc_auc': val_metrics['roc_auc'],
        'val_pr_auc': val_metrics['pr_auc'],
        'test_accuracy': test_metrics['accuracy'],
        'test_balanced_accuracy': test_metrics['balanced_accuracy'],
        'test_precision': test_metrics['precision'],
        'test_recall': test_metrics['recall'],
        'test_f1': test_metrics['f1'],
        'test_macro_f1': test_metrics['macro_f1'],
        'test_sensitivity': test_metrics['sensitivity'],
        'test_specificity': test_metrics['specificity'],
        'test_roc_auc': test_metrics['roc_auc'],
        'test_pr_auc': test_metrics['pr_auc'],
        'val_confusion_matrix': val_metrics['confusion_matrix'],
        'test_confusion_matrix': test_metrics['confusion_matrix'],
    }
    df_results = pd.DataFrame([results])
    out_path = Path("results/multiview_image_mean.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df_results.to_csv(out_path, index=False)
    print(f"\nResults saved to {out_path}")

    report = []
    report.append("MULTI-VIEW IMAGE MODEL REPORT (MEAN POOLING)")
    report.append("="*60)
    report.append(f"Model: MobileNetV3-Small shared encoder + mean pooling")
    report.append(f"Image size: {IMAGE_SIZE}x{IMAGE_SIZE}")
    report.append(f"Max views: {MAX_VIEWS}")
    report.append(f"Batch size: {BATCH_SIZE}")
    report.append(f"Learning rate: {LEARNING_RATE}")
    report.append(f"Embedding dim: {EMBED_DIM}")
    report.append(f"Class weight (positive): {pos_weight:.4f}")
    report.append(f"Valid training samples: {len(train_dataset)}")
    report.append(f"Valid validation samples: {len(val_dataset)}")
    report.append(f"Valid test samples: {len(test_dataset)}")
    report.append("\nValidation metrics:")
    for k, v in val_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            report.append(f"  {k}: {v}")
    report.append(f"Validation confusion matrix:\n{np.array(val_metrics['confusion_matrix'])}")
    report.append(f"Validation classification report:\n{classification_report(val_metrics['y_true'], val_metrics['y_pred'], zero_division=0)}")
    report.append("\nTest metrics:")
    for k, v in test_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            report.append(f"  {k}: {v}")
    report.append(f"Test confusion matrix:\n{np.array(test_metrics['confusion_matrix'])}")
    report.append(f"Test classification report:\n{classification_report(test_metrics['y_true'], test_metrics['y_pred'], zero_division=0)}")

    with open(Path("results/multiview_image_mean_report.txt"), 'w') as f:
        f.write('\n'.join(report))
    print(f"Report saved to {Path('results/multiview_image_mean_report.txt')}")


if __name__ == "__main__":
    main()
