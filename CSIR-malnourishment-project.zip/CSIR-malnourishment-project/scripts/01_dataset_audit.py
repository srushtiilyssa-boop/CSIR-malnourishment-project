#!/usr/bin/env python3
"""
ARAN Dataset Forensics - Phase 1
Inspect raw dataset, generate inventory, detect duplicates/corruption,
and compare 'data from anwar' with main image folders.
"""
import os
import hashlib
import pandas as pd
from pathlib import Path
from PIL import Image, UnidentifiedImageError
from collections import defaultdict
import json

RAW_DIR = Path("data/raw")
REPORT_PATH = Path("data/mappings/dataset_audit_report.txt")
INVENTORY_CSV = Path("data/mappings/image_inventory.csv")

def md5(filepath):
    hash_md5 = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def is_image(ext):
    return ext.lower() in {'.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff', '.tif'}

def main():
    Path("data/mappings").mkdir(parents=True, exist_ok=True)

    all_files = []
    for root, dirs, files in os.walk(RAW_DIR):
        for f in files:
            filepath = Path(root) / f
            rel = filepath.relative_to(RAW_DIR)
            all_files.append((rel, filepath))

    print(f"Total files found: {len(all_files)}")

    csv_files = [(rel, fp) for rel, fp in all_files if rel.suffix.lower() == '.csv']
    image_files = [(rel, fp) for rel, fp in all_files if is_image(rel.suffix)]

    print(f"CSV files: {len(csv_files)}")
    print(f"Image files: {len(image_files)}")

    metadata_df = None
    for rel, fp in csv_files:
        print(f"Examining CSV: {rel}")
        try:
            df = pd.read_csv(fp)
            print(f"  Columns: {list(df.columns)}")
            if any(col.lower() in ['id', 'child_id', 'age', 'gender', 'weight', 'height'] for col in df.columns):
                metadata_df = df
                print(f"  -> Using as primary metadata. Shape: {df.shape}")
        except Exception as e:
            print(f"  Error reading: {e}")

    if metadata_df is not None:
        print("\nMetadata sample:")
        print(metadata_df.head())
        metadata_df.to_csv(Path("data/mappings/metadata_inspected.csv"), index=False)
    else:
        print("WARNING: No metadata CSV identified. Please check manually.")

    inventory = []
    corrupted = []
    hash_to_paths = defaultdict(list)
    source_counts = defaultdict(int)
    gender_counts = defaultdict(int)
    child_image_counts = defaultdict(list)

    for rel, fp in image_files:
        record = {
            'relative_path': str(rel),
            'absolute_path': str(fp),
            'filename': fp.name,
            'parent_dir': str(rel.parent),
            'size_bytes': fp.stat().st_size,
        }
        parts = rel.parts
        record['source'] = parts[0] if len(parts) > 0 else 'root'
        path_lower = str(rel).lower()
        if 'male' in path_lower and 'female' not in path_lower:
            record['gender_hint'] = 'male'
        elif 'female' in path_lower:
            record['gender_hint'] = 'female'
        else:
            record['gender_hint'] = 'unknown'

        try:
            with Image.open(fp) as img:
                record['width'] = img.width
                record['height'] = img.height
                record['format'] = img.format
                record['mode'] = img.mode
                img.verify()
            file_hash = md5(fp)
            record['md5'] = file_hash
            hash_to_paths[file_hash].append(str(rel))
        except (UnidentifiedImageError, Exception) as e:
            record['width'] = None
            record['height'] = None
            record['format'] = None
            record['mode'] = None
            record['md5'] = 'CORRUPTED'
            corrupted.append(str(rel))
            print(f"CORRUPTED: {rel} - {e}")

        inventory.append(record)
        source_counts[record['source']] += 1
        gender_counts[record['gender_hint']] += 1

        import re
        nums = re.findall(r'\d+', fp.stem)
        if nums:
            child_id = nums[0]
        else:
            child_id = fp.stem
        child_image_counts[(record['gender_hint'], child_id)].append(str(rel))

    inv_df = pd.DataFrame(inventory)
    inv_df.to_csv(INVENTORY_CSV, index=False)
    print(f"\nImage inventory saved to {INVENTORY_CSV}")

    duplicates = {h: paths for h, paths in hash_to_paths.items() if len(paths) > 1}
    print(f"\nDuplicate images (by MD5): {len(duplicates)} groups")
    if duplicates:
        dup_report_path = Path("data/mappings/duplicate_images.json")
        with open(dup_report_path, 'w') as f:
            json.dump(duplicates, f, indent=2)
        print(f"Duplicate groups saved to {dup_report_path}")

    report = []
    report.append("="*60)
    report.append("ARAN DATASET AUDIT REPORT")
    report.append("="*60)
    report.append(f"Root directory: {RAW_DIR.resolve()}")
    report.append(f"Total files: {len(all_files)}")
    report.append(f"  Image files: {len(image_files)}")
    report.append(f"  CSV files: {len(csv_files)}")
    report.append(f"  Other: {len(all_files)-len(image_files)-len(csv_files)}")
    report.append(f"Corrupted images: {len(corrupted)}")
    if corrupted:
        report.append("Corrupted list:")
        for c in corrupted:
            report.append(f"  {c}")
    report.append("\nImage counts by source:")
    for src, cnt in source_counts.items():
        report.append(f"  {src}: {cnt}")
    report.append("\nGender hints from path:")
    for g, cnt in gender_counts.items():
        report.append(f"  {g}: {cnt}")
    report.append(f"\nUnique image hashes: {len(hash_to_paths)}")
    report.append(f"Duplicate groups: {len(duplicates)}")

    report.append("\nChildren per (gender_hint, child_id) grouping:")
    child_groups = defaultdict(int)
    for (gender, cid), imgs in child_image_counts.items():
        child_groups[gender] += 1
        report.append(f"  {gender} ID {cid}: {len(imgs)} images")
    report.append(f"Total unique child IDs (tentative): {sum(child_groups.values())}")

    main_image_hashes = set()
    anwar_hashes = set()
    for rec in inventory:
        if rec['md5'] == 'CORRUPTED':
            continue
        if 'data from anwar' in rec['relative_path'].lower():
            anwar_hashes.add(rec['md5'])
        else:
            main_image_hashes.add(rec['md5'])
    overlap = main_image_hashes.intersection(anwar_hashes)
    report.append(f"\n'data from anwar' analysis:")
    report.append(f"  Anwar images: {len(anwar_hashes)}")
    report.append(f"  Main images: {len(main_image_hashes)}")
    report.append(f"  Overlapping hashes: {len(overlap)}")
    if overlap:
        report.append("  Anwar is NOT a disjoint set; contains duplicates of main images.")

    with open(REPORT_PATH, 'w') as f:
        f.write('\n'.join(report))
    print(f"\nAudit report written to {REPORT_PATH}")

if __name__ == "__main__":
    main()
