#!/usr/bin/env python3
"""
Phase 1b: Build verified child-to-image mapping.
Reads metadata and image inventory, creates child_image_mapping.csv.
"""
import pandas as pd
import numpy as np
from pathlib import Path
import re

metadata_path = Path("data/mappings/metadata_inspected.csv")
if not metadata_path.exists():
    metadata_path = Path("data/raw/ARAN/labels.csv")  # adjust as found
metadata = pd.read_csv(metadata_path)
print("Metadata columns:", metadata.columns.tolist())

if 'child_id' in metadata.columns:
    pass
elif 'ID' in metadata.columns:
    metadata.rename(columns={'ID': 'child_id'}, inplace=True)
elif 'id' in metadata.columns:
    metadata.rename(columns={'id': 'child_id'}, inplace=True)
else:
    raise ValueError("Cannot find child ID column in metadata")

# Normalize child_id: keep as-is (e.g. 'child0001') but strip whitespace
def normalize_id(value):
    return str(value).strip().lower()

metadata['child_id_norm'] = metadata['child_id'].apply(normalize_id)

inventory = pd.read_csv(Path("data/mappings/image_inventory.csv"))
inventory = inventory[inventory['md5'] != 'CORRUPTED'].copy()

def extract_num_id(filename):
    """Extract base child ID from filename like 'child0001_01.jpg' -> 'child0001'"""
    stem = Path(filename).stem.lower()
    # Match pattern like 'child0001' (word + digits before underscore/end)
    match = re.match(r'(child\d+)', stem)
    if match:
        return match.group(1)
    # Fallback: just extract first number sequence
    nums = re.findall(r'\d+', stem)
    if nums:
        return str(int(nums[0]))
    return None

inventory['extracted_id_norm'] = inventory['filename'].apply(extract_num_id)

main_images = inventory[~inventory['relative_path'].str.lower().str.contains("data from anwar")].copy()
anwar_images = inventory[inventory['relative_path'].str.lower().str.contains("data from anwar")].copy()

def map_images_for_source(df_images, source_label):
    mappings = []
    for _, child in metadata.iterrows():
        cid = child['child_id_norm']
        child_gender = str(child.get('gender', '')).strip().lower()
        if child_gender in ['m', 'male', '1']:
            gender_str = 'male'
        elif child_gender in ['f', 'female', '2']:
            gender_str = 'female'
        else:
            continue

        imgs = df_images[
            (df_images['gender_hint'] == gender_str) &
            (df_images['extracted_id_norm'] == cid)
        ].copy()
        if imgs.empty:
            continue
        imgs = imgs.sort_values('filename')
        imgs['view_order'] = range(1, len(imgs)+1)
        confidence = 'high' if len(imgs) == 4 else 'medium' if 2 <= len(imgs) <= 3 else 'low'
        for _, row in imgs.iterrows():
            mappings.append({
                'child_id': cid,
                'image_path': row['relative_path'],
                'image_source': source_label,
                'view_id': f"view_{row['view_order']}",
                'gender': gender_str,
                'mapping_method': 'auto_sorted',
                'mapping_confidence': confidence
            })
    return pd.DataFrame(mappings)

main_mapping = map_images_for_source(main_images, 'main')
print(f"Main source mapped children: {main_mapping['child_id'].nunique()}")

anwar_mapping = map_images_for_source(anwar_images, 'anwar')
print(f"Anwar source mapped children: {anwar_mapping['child_id'].nunique()}")

consolidated = main_mapping.copy()
if not anwar_mapping.empty:
    for _, arow in anwar_mapping.iterrows():
        cid = arow['child_id']
        if cid in consolidated['child_id'].values:
            existing_paths = consolidated[consolidated['child_id'] == cid]['image_path'].tolist()
            if arow['image_path'] not in existing_paths:
                current_views = consolidated[consolidated['child_id'] == cid]['view_id'].tolist()
                max_view = max([int(v.split('_')[1]) for v in current_views])
                arow['view_id'] = f"view_{max_view+1}"
                consolidated = pd.concat([consolidated, pd.DataFrame([arow])], ignore_index=True)
        else:
            consolidated = pd.concat([consolidated, pd.DataFrame([arow])], ignore_index=True)

consolidated = consolidated.sort_values(['child_id', 'view_id'])
mapping_path = Path("data/mappings/child_image_mapping.csv")
consolidated.to_csv(mapping_path, index=False)
print(f"Consolidated mapping saved to {mapping_path} with {len(consolidated)} image entries for {consolidated['child_id'].nunique()} children.")

report_lines = []
report_lines.append("CHILD-IMAGE MAPPING SUMMARY")
report_lines.append(f"Total children with at least one image: {consolidated['child_id'].nunique()}")
counts = consolidated.groupby('child_id').size()
report_lines.append(f"Children with 1 image: {(counts==1).sum()}")
report_lines.append(f"Children with 2 images: {(counts==2).sum()}")
report_lines.append(f"Children with 3 images: {(counts==3).sum()}")
report_lines.append(f"Children with 4 images: {(counts==4).sum()}")
report_lines.append(f"Children with >4 images: {(counts>4).sum()}")
report_lines.append(f"Main source images: {len(main_mapping)}")
report_lines.append(f"Anwar source images: {len(anwar_mapping)}")
report_lines.append(f"Consolidated unique images: {len(consolidated)}")
mapped_ids = set(consolidated['child_id'])
meta_ids = set(metadata['child_id_norm'])
unmapped = meta_ids - mapped_ids
report_lines.append(f"Children in metadata but no images mapped: {len(unmapped)} (IDs: {sorted(unmapped)[:10]}...)")
low_conf = consolidated[consolidated['mapping_confidence']=='low']['child_id'].unique()
report_lines.append(f"Children with low mapping confidence: {len(low_conf)}")

with open(Path("data/mappings/mapping_report.txt"), 'w') as f:
    f.write('\n'.join(report_lines))
print("Mapping report written.")
