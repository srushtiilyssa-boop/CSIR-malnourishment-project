#!/usr/bin/env python3
"""
Phase 12: Federated learning simulation (FedAvg and FedProx) for cross-attention multimodal model.
"""
import pandas as pd
import numpy as np
from pathlib import Path
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision import models
import torch.nn.functional as F
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, accuracy_score, recall_score, precision_score, f1_score, balanced_accuracy_score
import copy, joblib
import matplotlib.pyplot as plt

torch.manual_seed(42)
np.random.seed(42)

RAW_DIR = Path("data/raw")
IMAGE_SIZE = 224
MAX_VIEWS = 4
BATCH_SIZE = 8
LOCAL_EPOCHS = 2
COMM_ROUNDS = 20
LEARNING_RATE = 1e-4
IMG_EMBED_DIM = 256
TAB_EMBED_DIM = 128
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

TABULAR_FEATURES = ['age_months', 'gender', 'head_circumference_cm', 'waist_circumference_cm']
NUMERIC_FEATURES = ['age_months', 'head_circumference_cm', 'waist_circumference_cm']
CATEGORICAL_FEATURES = ['gender']

# ---------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------
def build_preprocessor():
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, NUMERIC_FEATURES),
            ('cat', categorical_transformer, CATEGORICAL_FEATURES)
        ]
    )
    return preprocessor

# ---------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------
class MultimodalDataset(Dataset):
    def __init__(self, df, tabular_preprocessor, transform=None, max_views=4, fit_preprocessor=False):
        self.df = df.reset_index(drop=True)
        self.transform = transform
        self.max_views = max_views
        self.tabular_preprocessor = tabular_preprocessor
        self.valid_indices = []
        self.image_paths = []

        if fit_preprocessor:
            tabular_array = self.tabular_preprocessor.fit_transform(df[TABULAR_FEATURES])
        else:
            tabular_array = self.tabular_preprocessor.transform(df[TABULAR_FEATURES])
        self.tabular_features = tabular_array.astype(np.float32)

        for idx, row in self.df.iterrows():
            paths = []
            for col in ['image_1', 'image_2', 'image_3', 'image_4', 'image_5']:
                if col in row and pd.notna(row[col]):
                    rel_path = str(row[col]).strip().replace('/', '\\')
                    full_path = RAW_DIR / rel_path
                    if full_path.exists():
                        try:
                            with Image.open(full_path) as img:
                                img.verify()
                            paths.append(full_path)
                            if len(paths) >= max_views:
                                break
                        except Exception:
                            continue
            if len(paths) > 0:
                self.valid_indices.append(idx)
                self.image_paths.append(paths)
        print(f"Dataset: {len(self.valid_indices)} valid samples out of {len(df)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        row_idx = self.valid_indices[idx]
        row = self.df.iloc[row_idx]
        paths = self.image_paths[idx]
        images = []
        for p in paths:
            try:
                img = Image.open(p).convert('RGB')
            except Exception:
                img = Image.new('RGB', (IMAGE_SIZE, IMAGE_SIZE), (0, 0, 0))
            if self.transform:
                img = self.transform(img)
            images.append(img)
        while len(images) < self.max_views:
            images.append(torch.zeros_like(images[0]))
        image_tensor = torch.stack(images, dim=0)
        mask = torch.zeros(self.max_views, dtype=torch.float32)
        mask[:len(paths)] = 1.0
        tabular_tensor = torch.tensor(self.tabular_features[row_idx], dtype=torch.float32)
        label = torch.tensor(row['undernutrition_risk'], dtype=torch.float32)
        return image_tensor, mask, tabular_tensor, label

# ---------------------------------------------------------------------
# Transforms
# ---------------------------------------------------------------------
train_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomRotation(degrees=5),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
eval_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# ---------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------
class ImageEncoderResNet(nn.Module):
    def __init__(self, embed_dim=256):
        super().__init__()
        base = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
        self.features = nn.Sequential(*list(base.children())[:-1])
        self.projection = nn.Linear(512, embed_dim)
    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.projection(x)
        return x

class TabularEncoder(nn.Module):
    def __init__(self, input_dim, embed_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, embed_dim)
        )
    def forward(self, x):
        return self.net(x)

class AttentionPooling(nn.Module):
    def __init__(self, embed_dim):
        super().__init__()
        self.attn = nn.Linear(embed_dim, 1)
    def forward(self, embeddings, mask):
        scores = self.attn(embeddings).squeeze(-1)
        scores = scores.masked_fill(mask == 0, -1e9)
        weights = F.softmax(scores, dim=1).unsqueeze(-1)
        pooled = (embeddings * weights).sum(dim=1)
        return pooled

class CrossAttentionMultimodal(nn.Module):
    def __init__(self, tab_input_dim):
        super().__init__()
        self.image_encoder = ImageEncoderResNet(IMG_EMBED_DIM)
        self.pool = AttentionPooling(IMG_EMBED_DIM)
        self.tabular_encoder = TabularEncoder(tab_input_dim, TAB_EMBED_DIM)
        self.img_proj = nn.Linear(IMG_EMBED_DIM, 128)
        self.tab_proj = nn.Linear(TAB_EMBED_DIM, 128)
        self.attn = nn.MultiheadAttention(embed_dim=128, num_heads=4, batch_first=True)
        self.norm = nn.LayerNorm(128)
        self.fusion = nn.Sequential(
            nn.Linear(128 + TAB_EMBED_DIM, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    def forward(self, images, mask, tabular):
        B, V, C, H, W = images.shape
        flat = images.view(B * V, C, H, W)
        embeds = self.image_encoder(flat).view(B, V, -1)
        img_embed = self.pool(embeds, mask)
        tab_embed = self.tabular_encoder(tabular)
        q = self.img_proj(img_embed).unsqueeze(1)
        k = self.tab_proj(tab_embed).unsqueeze(1)
        attn_out, _ = self.attn(q, k, k)
        attn_out = self.norm(attn_out.squeeze(1))
        combined = torch.cat([attn_out, tab_embed], dim=1)
        return self.fusion(combined)

# ---------------------------------------------------------------------
# Federated helpers
# ---------------------------------------------------------------------
def partition_iid(df, num_clients):
    shuffled_indices = np.random.permutation(len(df))
    splits = np.array_split(shuffled_indices, num_clients)
    return [df.iloc[split].reset_index(drop=True) for split in splits]

def partition_non_iid(df, num_clients, alpha=0.5):
    labels = df['undernutrition_risk'].values
    unique_labels = np.unique(labels)
    label_indices = {l: np.where(labels == l)[0] for l in unique_labels}
    client_indices = [[] for _ in range(num_clients)]
    for l, idxs in label_indices.items():
        np.random.shuffle(idxs)
        proportions = np.random.dirichlet(np.repeat(alpha, num_clients))
        proportions = (proportions * len(idxs)).astype(int)
        proportions[-1] = len(idxs) - proportions[:-1].sum()
        start = 0
        for c, count in enumerate(proportions):
            client_indices[c].extend(idxs[start:start+count])
            start += count
    client_dfs = [df.iloc[idxs].reset_index(drop=True) for idxs in client_indices]
    return client_dfs

def compute_metrics(y_true, y_pred, y_proba):
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel()
    return {
        'accuracy': accuracy_score(y_true, y_pred),
        'balanced_accuracy': balanced_accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred, zero_division=0),
        'recall': recall_score(y_true, y_pred, zero_division=0),
        'sensitivity': recall_score(y_true, y_pred, zero_division=0),
        'specificity': recall_score(y_true, y_pred, pos_label=0, zero_division=0),
        'f1': f1_score(y_true, y_pred, zero_division=0),
        'roc_auc': roc_auc_score(y_true, y_proba),
        'pr_auc': average_precision_score(y_true, y_proba),
        'confusion_matrix': cm.tolist()
    }

def predict_proba(model, loader, device):
    model.eval()
    all_probs, all_labels = [], []
    with torch.no_grad():
        for images, mask, tabular, labels in loader:
            images, mask, tabular, labels = images.to(device), mask.to(device), tabular.to(device), labels.to(device)
            logits = model(images, mask, tabular)
            probs = torch.sigmoid(logits).cpu().numpy().flatten()
            all_probs.extend(probs)
            all_labels.extend(labels.cpu().numpy())
    return np.array(all_probs), np.array(all_labels)

def main():
    # Load data
    train_df = pd.read_csv(Path("data/splits/train.csv"))
    val_df = pd.read_csv(Path("data/splits/validation.csv"))
    test_df = pd.read_csv(Path("data/splits/test.csv"))

    preprocessor = build_preprocessor()
    _ = preprocessor.fit_transform(train_df[TABULAR_FEATURES])

    val_dataset = MultimodalDataset(val_df, preprocessor, transform=eval_transform,
                                    max_views=MAX_VIEWS, fit_preprocessor=False)
    test_dataset = MultimodalDataset(test_df, preprocessor, transform=eval_transform,
                                     max_views=MAX_VIEWS, fit_preprocessor=False)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

    tab_input_dim = preprocessor.transform(train_df[TABULAR_FEATURES]).shape[1]
    print(f"Tabular input dimension: {tab_input_dim}")

    num_clients = 5
    all_results = []

    for distribution in ['iid', 'non_iid']:
        if distribution == 'iid':
            client_dfs = partition_iid(train_df, num_clients)
        else:
            client_dfs = partition_non_iid(train_df, num_clients, alpha=0.5)
        print(f"\n=== Distribution: {distribution} ===")
        for client_id, cdf in enumerate(client_dfs):
            print(f"Client {client_id}: {len(cdf)} samples, risk count={cdf['undernutrition_risk'].sum()}")

        client_datasets = []
        for cdf in client_dfs:
            ds = MultimodalDataset(cdf, preprocessor, transform=train_transform,
                                   max_views=MAX_VIEWS, fit_preprocessor=False)
            client_datasets.append(ds)
        client_loaders = [DataLoader(ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
                          for ds in client_datasets]
        client_sizes = [len(ds) for ds in client_datasets]
        total_size = sum(client_sizes)

        y_train_full = train_df.loc[:, 'undernutrition_risk'].values
        pos_count = np.sum(y_train_full == 1)
        neg_count = np.sum(y_train_full == 0)
        pos_weight = neg_count / pos_count if pos_count > 0 else 1.0

        for method in ['FedAvg', 'FedProx']:
            print(f"  Training with {method}...")
            global_model = CrossAttentionMultimodal(tab_input_dim).to(DEVICE)
            global_weights = copy.deepcopy(global_model.state_dict())

            val_roc_history = []
            test_roc_history = []
            best_test_metrics = None

            for round_idx in range(1, COMM_ROUNDS+1):
                client_updates = []
                client_weights = []
                for cid, loader in enumerate(client_loaders):
                    local_model = CrossAttentionMultimodal(tab_input_dim).to(DEVICE)
                    local_model.load_state_dict(global_weights)
                    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE)
                    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([pos_weight]).to(DEVICE))

                    local_model.train()
                    for _ in range(LOCAL_EPOCHS):
                        for images, mask, tabular, labels in loader:
                            images, mask, tabular, labels = images.to(DEVICE), mask.to(DEVICE), tabular.to(DEVICE), labels.to(DEVICE).unsqueeze(1)
                            optimizer.zero_grad()
                            logits = local_model(images, mask, tabular)
                            loss = criterion(logits, labels)
                            if method == 'FedProx':
                                prox_term = 0.0
                                for local_param, global_param in zip(local_model.parameters(), global_model.parameters()):
                                    prox_term += torch.norm(local_param - global_param) ** 2
                                loss += 0.5 * 0.1 * prox_term
                            loss.backward()
                            optimizer.step()
                    client_updates.append(copy.deepcopy(local_model.state_dict()))
                    client_weights.append(client_sizes[cid] / total_size)

                aggregated = copy.deepcopy(global_weights)
                for key in aggregated.keys():
                    # Only aggregate floating point parameters
                    if aggregated[key].dtype in [torch.float32, torch.float64]:
                        aggregated[key] = torch.zeros_like(aggregated[key])
                        for upd, w in zip(client_updates, client_weights):
                            aggregated[key] += w * upd[key]
                    # Non-float parameters are kept from first client
                global_weights = aggregated
                global_model.load_state_dict(global_weights)

                val_probs, val_labels = predict_proba(global_model, val_loader, DEVICE)
                test_probs, test_labels = predict_proba(global_model, test_loader, DEVICE)
                val_roc = roc_auc_score(val_labels, val_probs)
                test_roc = roc_auc_score(test_labels, test_probs)
                val_roc_history.append(val_roc)
                test_roc_history.append(test_roc)
                print(f"    Round {round_idx}/{COMM_ROUNDS} | Val ROC-AUC: {val_roc:.4f} | Test ROC-AUC: {test_roc:.4f}")

                if test_roc >= max(test_roc_history):
                    best_test_metrics = compute_metrics(test_labels, (test_probs >= 0.5).astype(int), test_probs)

            all_results.append({
                'distribution': distribution,
                'method': method,
                'test_roc_auc': best_test_metrics['roc_auc'],
                'test_sensitivity': best_test_metrics['sensitivity'],
                'test_specificity': best_test_metrics['specificity'],
                'test_f1': best_test_metrics['f1'],
                'test_balanced_accuracy': best_test_metrics['balanced_accuracy'],
                'val_roc_history': val_roc_history,
                'test_roc_history': test_roc_history
            })

    results_df = pd.DataFrame([{k: v for k, v in r.items() if k not in ['val_roc_history', 'test_roc_history']}
                               for r in all_results])
    results_df.to_csv("results/federated_results.csv", index=False)
    print("\nFederated results saved to results/federated_results.csv")
    print(results_df[['distribution', 'method', 'test_roc_auc', 'test_sensitivity', 'test_specificity', 'test_f1']].to_string(index=False))

    plt.figure(figsize=(8,5))
    for r in all_results:
        label = f"{r['distribution']} - {r['method']}"
        plt.plot(range(1, COMM_ROUNDS+1), r['test_roc_history'], label=label)
    plt.xlabel('Communication Round')
    plt.ylabel('Test ROC-AUC')
    plt.title('Federated Learning Convergence')
    plt.legend()
    plt.grid(True)
    plt.savefig("results/federated_convergence.png", dpi=300, bbox_inches='tight')
    plt.close()
    print("Convergence plot saved to results/federated_convergence.png")

if __name__ == "__main__":
    main()
