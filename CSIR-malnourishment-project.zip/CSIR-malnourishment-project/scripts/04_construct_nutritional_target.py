#!/usr/bin/env python3
"""
Phase 3 (corrected): Construct nutritional risk target using WHO growth standards.
Uses pygrowup correctly: WHO2006 for <=60 months, WHO2007/CDC for >60 months.
"""
import pandas as pd
import numpy as np
from pathlib import Path
import json

def compute_z_scores(df):
    """Compute WHO z-scores for each child using pygrowup."""
    try:
        from pygrowup import Calculator
    except ImportError:
        raise ImportError("Please install pygrowup: pip install pygrowup")

    calc = Calculator(include_cdc=True)

    z_wfa = []
    z_hfa = []
    z_wfh_or_bmi = []  # WHZ for <=60m, BAZ for >60m

    for _, row in df.iterrows():
        age_months = row['age_months']
        sex = str(row['gender']).strip().lower()
        sex_code = 'M' if sex in ['male', 'm', '1'] else 'F'
        weight_kg = row['weight_g'] / 1000.0
        height_cm = row['height_cm']

        if pd.isna(age_months) or pd.isna(weight_kg) or pd.isna(height_cm):
            z_wfa.append(np.nan)
            z_hfa.append(np.nan)
            z_wfh_or_bmi.append(np.nan)
            continue

        # Weight-for-age
        try:
            waz = float(calc.zscore_for_measurement('wfa', measurement=weight_kg, age_in_months=age_months, sex=sex_code))
        except Exception:
            waz = np.nan

        # Height-for-age (lhfa in pygrowup)
        try:
            haz = float(calc.zscore_for_measurement('lhfa', measurement=height_cm, age_in_months=age_months, sex=sex_code))
        except Exception:
            haz = np.nan

        # Weight-for-length/height (<=60m) or BMI-for-age (>60m)
        whz = np.nan
        if age_months <= 60:
            try:
                whz = float(calc.zscore_for_measurement('wfl', measurement=weight_kg, age_in_months=age_months, sex=sex_code, height=height_cm))
            except Exception:
                try:
                    whz = float(calc.zscore_for_measurement('wfh', measurement=weight_kg, age_in_months=age_months, sex=sex_code, height=height_cm))
                except Exception:
                    whz = np.nan

        if pd.isna(whz):
            try:
                bmi = weight_kg / ((height_cm / 100.0) ** 2)
                whz = float(calc.zscore_for_measurement('bmifa', measurement=bmi, age_in_months=age_months, sex=sex_code))
            except Exception:
                whz = np.nan

        z_wfa.append(waz)
        z_hfa.append(haz)
        z_wfh_or_bmi.append(whz)

    df['z_wfa'] = z_wfa
    df['z_hfa'] = z_hfa
    df['z_wfh_or_bmi'] = z_wfh_or_bmi
    return df

def define_target(df):
    """Define binary target: 1 if any z-score < -2, else 0."""
    conditions = [
        (df['z_wfa'] < -2),
        (df['z_hfa'] < -2),
        (df['z_wfh_or_bmi'] < -2)
    ]
    df['undernutrition_risk'] = np.any(conditions, axis=0).astype(int)
    return df

def main():
    child_df = pd.read_csv(Path("data/processed/child_multimodal_dataset.csv"))

    child_df['gender'] = child_df['gender'].astype(str).str.strip().str.lower()
    valid_gender = ['male', 'female', 'm', 'f', '1', '2']
    child_df = child_df[child_df['gender'].isin(valid_gender)]

    required_for_z = ['age_months', 'weight_g', 'height_cm']
    child_df = child_df.dropna(subset=required_for_z)

    child_df = compute_z_scores(child_df)
    child_df = define_target(child_df)

    target_cols = ['child_id', 'gender', 'age_months', 'height_cm', 'weight_g',
                   'head_circumference_cm', 'waist_circumference_cm',
                   'z_wfa', 'z_hfa', 'z_wfh_or_bmi', 'undernutrition_risk']
    target_df = child_df[target_cols]
    out_path = Path("data/processed/nutritional_targets.csv")
    target_df.to_csv(out_path, index=False)
    print(f"Nutritional targets saved to {out_path}")

    feature_sets = {
        "full_tabular": ["age_months", "gender", "height_cm", "weight_g",
                         "head_circumference_cm", "waist_circumference_cm"],
        "leakage_controlled_tabular": ["age_months", "gender",
                                        "head_circumference_cm", "waist_circumference_cm"],
        "image_only": None,
        "multimodal": ["age_months", "gender", "head_circumference_cm",
                       "waist_circumference_cm"]
    }
    with open(Path("data/processed/feature_sets.json"), 'w') as f:
        json.dump(feature_sets, f, indent=2)
    print("Feature sets saved to data/processed/feature_sets.json")

    report = []
    report.append("NUTRITIONAL TARGET CONSTRUCTION REPORT (CORRECTED)")
    report.append("="*60)
    report.append(f"Total children with valid anthropometrics: {len(child_df)}")
    report.append(f"Age range: {child_df['age_months'].min()} - {child_df['age_months'].max()} months")
    report.append(f"Gender distribution:\n{child_df['gender'].value_counts().to_string()}")
    report.append(f"\nTarget distribution (undernutrition_risk):\n{child_df['undernutrition_risk'].value_counts().to_string()}")
    report.append(f"\nMissing z-scores:")
    report.append(f"  WAZ missing: {child_df['z_wfa'].isna().sum()}")
    report.append(f"  HAZ missing: {child_df['z_hfa'].isna().sum()}")
    report.append(f"  WHZ/BAZ missing: {child_df['z_wfh_or_bmi'].isna().sum()}")
    report.append(f"\nLeakage analysis:")
    report.append("  Target is derived from: age, gender, weight, height.")
    report.append("  Full tabular features include: age, gender, height, weight, head_circumference, waist_circumference.")
    report.append("  Leakage-controlled tabular features exclude weight and height (and any derived indicators).")
    report.append("  Image features are always leakage-free for anthropometric target.")
    report.append("\nSuggested feature sets saved in data/processed/feature_sets.json")

    with open(Path("data/processed/target_report.txt"), 'w') as f:
        f.write('\n'.join(report))
    print("Report saved to data/processed/target_report.txt")
    print('\n'.join(report))

if __name__ == "__main__":
    main()
