#!/usr/bin/env python3
"""
Phase 6: Image-only baseline (single view)
Uses a pretrained MobileNetV3-Small on one image per child.
Robust to truncated images.
"""
import pandas as pd
import numpy as np
from pathlib import Path
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision import models
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, average_precision_score, confusion_matrix,
    classification_report
)
import json, time, copy

# Reproducibility
torch.manual_seed(42)
np.random.seed(42)

RAW_DIR = Path("data/raw")
IMAGE_SIZE = 224
BATCH_SIZE = 16
EPOCHS = 20
LEARNING_RATE = 1e-4
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

# ---------------------------------------------------------------------
# Dataset class
# ---------------------------------------------------------------------
class SingleViewDataset(Dataset):
    def __init__(self, df, transform=None):
        """
        df: DataFrame with columns 'child_id', 'undernutrition_risk', and image paths.
        We will pick the first available and openable image among image_1..image_5.
        """
        self.df = df.reset_index(drop=True)
        self.transform = transform
        self.valid_indices = []
        self.image_paths = []
        for idx, row in self.df.iterrows():
            path_found = None
            for col in ['image_1', 'image_2', 'image_3', 'image_4', 'image_5']:
                if col in row and pd.notna(row[col]):
                    rel_path = str(row[col]).strip().replace('/', '\\')
                    full_path = RAW_DIR / rel_path
                    if full_path.exists():
                        # Test if image can be opened; if not, try next view
                        try:
                            with Image.open(full_path) as img:
                                img.verify()
                            # Re-open for actual loading later
                            path_found = full_path
                            break
                        except Exception as e:
                            continue
            if path_found is not None:
                self.valid_indices.append(idx)
                self.image_paths.append(path_found)
        print(f"Dataset: {len(self.valid_indices)} valid samples out of {len(df)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        row_idx = self.valid_indices[idx]
        row = self.df.iloc[row_idx]
        img_path = self.image_paths[idx]
        try:
            image = Image.open(img_path).convert('RGB')
        except Exception:
            # Fallback: create a black image (should not happen due to pre-check)
            image = Image.new('RGB', (IMAGE_SIZE, IMAGE_SIZE), (0, 0, 0))
        if self.transform:
            image = self.transform(image)
        label = torch.tensor(row['undernutrition_risk'], dtype=torch.float32)
        return image, label

# ---------------------------------------------------------------------
# Transforms
# ---------------------------------------------------------------------
train_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomRotation(degrees=5),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
eval_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# ---------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------
def build_model(num_classes=1):
    model = models.mobilenet_v3_small(pretrained=True)
    in_features = model.classifier[-1].in_features
    model.classifier[-1] = nn.Linear(in_features, num_classes)
    return model.to(DEVICE)

# ---------------------------------------------------------------------
# Training & evaluation
# ---------------------------------------------------------------------
def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    running_loss = 0.0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device).unsqueeze(1)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * images.size(0)
    return running_loss / len(loader.dataset)

def evaluate(model, loader, device):
    model.eval()
    all_preds = []
    all_labels = []
    all_probs = []
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            probs = torch.sigmoid(outputs).cpu().numpy().flatten()
            preds = (probs >= 0.5).astype(int)
            all_probs.extend(probs)
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())
    metrics = compute_metrics(all_labels, all_preds, all_probs)
    metrics['y_true'] = all_labels
    metrics['y_pred'] = all_preds
    metrics['y_proba'] = all_probs
    return metrics

def compute_metrics(y_true, y_pred, y_proba):
    acc = accuracy_score(y_true, y_pred)
    bal_acc = balanced_accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    macro_f1 = f1_score(y_true, y_pred, average='macro', zero_division=0)
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    roc_auc = roc_auc_score(y_true, y_proba)
    pr_auc = average_precision_score(y_true, y_proba)
    return {
        'accuracy': acc,
        'balanced_accuracy': bal_acc,
        'precision': prec,
        'recall': rec,
        'f1': f1,
        'macro_f1': macro_f1,
        'sensitivity': sensitivity,
        'specificity': specificity,
        'roc_auc': roc_auc,
        'pr_auc': pr_auc,
        'confusion_matrix': cm.tolist()
    }

def main():
    # Load splits
    train_df = pd.read_csv(Path("data/splits/train.csv"))
    val_df = pd.read_csv(Path("data/splits/validation.csv"))
    test_df = pd.read_csv(Path("data/splits/test.csv"))

    train_dataset = SingleViewDataset(train_df, transform=train_transform)
    val_dataset = SingleViewDataset(val_df, transform=eval_transform)
    test_dataset = SingleViewDataset(test_df, transform=eval_transform)

    y_train = train_df.loc[train_dataset.valid_indices, 'undernutrition_risk'].values
    pos_count = np.sum(y_train == 1)
    neg_count = np.sum(y_train == 0)
    pos_weight = neg_count / pos_count if pos_count > 0 else 1.0
    pos_weight_tensor = torch.tensor([pos_weight]).to(DEVICE)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight_tensor)

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

    model = build_model()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    best_val_roc = -1
    best_model_state = None
    patience = 5
    epochs_no_improve = 0

    print("Starting training...")
    for epoch in range(1, EPOCHS+1):
        train_loss = train_one_epoch(model, train_loader, optimizer, criterion, DEVICE)
        val_metrics = evaluate(model, val_loader, DEVICE)
        print(f"Epoch {epoch}/{EPOCHS} | Train Loss: {train_loss:.4f} | Val ROC-AUC: {val_metrics['roc_auc']:.4f} | Val Sens: {val_metrics['sensitivity']:.4f}")

        if val_metrics['roc_auc'] > best_val_roc:
            best_val_roc = val_metrics['roc_auc']
            best_model_state = copy.deepcopy(model.state_dict())
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= patience:
                print(f"Early stopping triggered after {epoch} epochs.")
                break

    if best_model_state:
        model.load_state_dict(best_model_state)

    val_metrics = evaluate(model, val_loader, DEVICE)
    test_metrics = evaluate(model, test_loader, DEVICE)

    print("\nValidation metrics:")
    for k, v in val_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            print(f"  {k}: {v}")
    print(f"  Confusion matrix:\n  {np.array(val_metrics['confusion_matrix'])}")
    print("\nTest metrics:")
    for k, v in test_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            print(f"  {k}: {v}")
    print(f"  Confusion matrix:\n  {np.array(test_metrics['confusion_matrix'])}")

    # Save results
    results = {
        'model': 'MobileNetV3-Small (single view)',
        'feature_set': 'image_only',
        'val_accuracy': val_metrics['accuracy'],
        'val_balanced_accuracy': val_metrics['balanced_accuracy'],
        'val_precision': val_metrics['precision'],
        'val_recall': val_metrics['recall'],
        'val_f1': val_metrics['f1'],
        'val_macro_f1': val_metrics['macro_f1'],
        'val_sensitivity': val_metrics['sensitivity'],
        'val_specificity': val_metrics['specificity'],
        'val_roc_auc': val_metrics['roc_auc'],
        'val_pr_auc': val_metrics['pr_auc'],
        'test_accuracy': test_metrics['accuracy'],
        'test_balanced_accuracy': test_metrics['balanced_accuracy'],
        'test_precision': test_metrics['precision'],
        'test_recall': test_metrics['recall'],
        'test_f1': test_metrics['f1'],
        'test_macro_f1': test_metrics['macro_f1'],
        'test_sensitivity': test_metrics['sensitivity'],
        'test_specificity': test_metrics['specificity'],
        'test_roc_auc': test_metrics['roc_auc'],
        'test_pr_auc': test_metrics['pr_auc'],
        'val_confusion_matrix': val_metrics['confusion_matrix'],
        'test_confusion_matrix': test_metrics['confusion_matrix'],
    }
    df_results = pd.DataFrame([results])
    out_path = Path("results/image_single_view.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df_results.to_csv(out_path, index=False)
    print(f"\nResults saved to {out_path}")

    # Write detailed report
    report = []
    report.append("IMAGE SINGLE VIEW BASELINE REPORT")
    report.append("="*60)
    report.append(f"Model: MobileNetV3-Small (pretrained)")
    report.append(f"Image size: {IMAGE_SIZE}x{IMAGE_SIZE}")
    report.append(f"Batch size: {BATCH_SIZE}")
    report.append(f"Learning rate: {LEARNING_RATE}")
    report.append(f"Epochs: {EPOCHS}")
    report.append(f"Class weight (positive): {pos_weight:.4f}")
    report.append(f"Valid training samples: {len(train_dataset)}")
    report.append(f"Valid validation samples: {len(val_dataset)}")
    report.append(f"Valid test samples: {len(test_dataset)}")
    report.append("\nValidation metrics:")
    for k, v in val_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            report.append(f"  {k}: {v}")
    report.append(f"Validation confusion matrix:\n{np.array(val_metrics['confusion_matrix'])}")
    report.append(f"Validation classification report:\n{classification_report(val_metrics['y_true'], val_metrics['y_pred'], zero_division=0)}")
    report.append("\nTest metrics:")
    for k, v in test_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            report.append(f"  {k}: {v}")
    report.append(f"Test confusion matrix:\n{np.array(test_metrics['confusion_matrix'])}")
    report.append(f"Test classification report:\n{classification_report(test_metrics['y_true'], test_metrics['y_pred'], zero_division=0)}")

    with open(Path("results/image_single_view_report.txt"), 'w') as f:
        f.write('\n'.join(report))
    print(f"Report saved to {Path('results/image_single_view_report.txt')}")

if __name__ == "__main__":
    main()