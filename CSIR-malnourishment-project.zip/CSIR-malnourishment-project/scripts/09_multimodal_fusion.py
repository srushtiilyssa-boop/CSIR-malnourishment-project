#!/usr/bin/env python3
"""
Phase 8: Centralized multimodal fusion (image + leakage-controlled tabular)
Simple concatenation fusion.
"""
import pandas as pd
import numpy as np
from pathlib import Path
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision import models
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, average_precision_score, confusion_matrix,
    classification_report
)
import copy, json, joblib

# Reproducibility
torch.manual_seed(42)
np.random.seed(42)

RAW_DIR = Path("data/raw")
IMAGE_SIZE = 224
MAX_VIEWS = 4
BATCH_SIZE = 8
EPOCHS = 20
LEARNING_RATE = 1e-4
IMG_EMBED_DIM = 128
TAB_EMBED_DIM = 64
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

TABULAR_FEATURES = ['age_months', 'gender', 'head_circumference_cm', 'waist_circumference_cm']
NUMERIC_FEATURES = ['age_months', 'head_circumference_cm', 'waist_circumference_cm']
CATEGORICAL_FEATURES = ['gender']

# ---------------------------------------------------------------------
# Data preprocessing for tabular features
# ---------------------------------------------------------------------
def build_preprocessor():
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, NUMERIC_FEATURES),
            ('cat', categorical_transformer, CATEGORICAL_FEATURES)
        ]
    )
    return preprocessor

# ---------------------------------------------------------------------
# Dataset class
# ---------------------------------------------------------------------
class MultimodalDataset(Dataset):
    def __init__(self, df, tabular_preprocessor, transform=None, max_views=4, fit_preprocessor=False):
        self.df = df.reset_index(drop=True)
        self.transform = transform
        self.max_views = max_views
        self.tabular_preprocessor = tabular_preprocessor
        self.valid_indices = []
        self.image_paths = []

        # Preprocess tabular features for all rows
        if fit_preprocessor:
            tabular_array = self.tabular_preprocessor.fit_transform(df[TABULAR_FEATURES])
        else:
            tabular_array = self.tabular_preprocessor.transform(df[TABULAR_FEATURES])
        self.tabular_features = tabular_array.astype(np.float32)

        # Find valid image paths per child
        for idx, row in self.df.iterrows():
            paths = []
            for col in ['image_1', 'image_2', 'image_3', 'image_4', 'image_5']:
                if col in row and pd.notna(row[col]):
                    rel_path = str(row[col]).strip().replace('/', '\\')
                    full_path = RAW_DIR / rel_path
                    if full_path.exists():
                        try:
                            with Image.open(full_path) as img:
                                img.verify()
                            paths.append(full_path)
                            if len(paths) >= max_views:
                                break
                        except Exception:
                            continue
            if len(paths) > 0:
                self.valid_indices.append(idx)
                self.image_paths.append(paths)
        print(f"Dataset: {len(self.valid_indices)} valid samples out of {len(df)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        row_idx = self.valid_indices[idx]
        row = self.df.iloc[row_idx]
        paths = self.image_paths[idx]
        images = []
        for p in paths:
            try:
                img = Image.open(p).convert('RGB')
            except Exception:
                img = Image.new('RGB', (IMAGE_SIZE, IMAGE_SIZE), (0, 0, 0))
            if self.transform:
                img = self.transform(img)
            images.append(img)
        while len(images) < self.max_views:
            images.append(torch.zeros_like(images[0]))
        image_tensor = torch.stack(images, dim=0)  # (max_views, 3, H, W)
        mask = torch.zeros(self.max_views, dtype=torch.float32)
        mask[:len(paths)] = 1.0
        tabular_tensor = torch.tensor(self.tabular_features[row_idx], dtype=torch.float32)
        label = torch.tensor(row['undernutrition_risk'], dtype=torch.float32)
        return image_tensor, mask, tabular_tensor, label

# ---------------------------------------------------------------------
# Transforms
# ---------------------------------------------------------------------
train_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomRotation(degrees=5),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
eval_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# ---------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------
class SharedImageEncoder(nn.Module):
    def __init__(self, embed_dim=128):
        super().__init__()
        base = models.mobilenet_v3_small(weights=models.MobileNet_V3_Small_Weights.IMAGENET1K_V1)
        self.features = base.features
        self.avgpool = base.avgpool
        self.projection = nn.Linear(576, embed_dim)
    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.projection(x)
        return x

class TabularEncoder(nn.Module):
    def __init__(self, input_dim, embed_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, embed_dim)
        )
    def forward(self, x):
        return self.net(x)

class MultimodalConcatModel(nn.Module):
    def __init__(self, image_embed_dim=128, tab_input_dim=None, tab_embed_dim=64):
        super().__init__()
        self.image_encoder = SharedImageEncoder(image_embed_dim)
        self.tabular_encoder = TabularEncoder(tab_input_dim, tab_embed_dim)
        fusion_input_dim = image_embed_dim + tab_embed_dim
        self.fusion = nn.Sequential(
            nn.Linear(fusion_input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )
    def forward(self, images, mask, tabular):
        B, V, C, H, W = images.shape
        flat_images = images.view(B * V, C, H, W)
        flat_embeddings = self.image_encoder(flat_images)
        embeddings = flat_embeddings.view(B, V, -1)
        mask_expanded = mask.unsqueeze(-1)
        sum_embeddings = (embeddings * mask_expanded).sum(dim=1)
        valid_counts = mask_expanded.sum(dim=1).clamp(min=1)
        image_pooled = sum_embeddings / valid_counts  # (B, image_embed_dim)
        tab_embed = self.tabular_encoder(tabular)     # (B, tab_embed_dim)
        fusion_input = torch.cat([image_pooled, tab_embed], dim=1)
        logits = self.fusion(fusion_input)
        return logits

# ---------------------------------------------------------------------
# Training & evaluation
# ---------------------------------------------------------------------
def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    running_loss = 0.0
    for images, mask, tabular, labels in loader:
        images, mask, tabular, labels = images.to(device), mask.to(device), tabular.to(device), labels.to(device).unsqueeze(1)
        optimizer.zero_grad()
        logits = model(images, mask, tabular)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * images.size(0)
    return running_loss / len(loader.dataset)

def evaluate(model, loader, device):
    model.eval()
    all_preds = []
    all_labels = []
    all_probs = []
    with torch.no_grad():
        for images, mask, tabular, labels in loader:
            images, mask, tabular, labels = images.to(device), mask.to(device), tabular.to(device), labels.to(device)
            logits = model(images, mask, tabular)
            probs = torch.sigmoid(logits).cpu().numpy().flatten()
            preds = (probs >= 0.5).astype(int)
            all_probs.extend(probs)
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())
    metrics = compute_metrics(all_labels, all_preds, all_probs)
    metrics['y_true'] = all_labels
    metrics['y_pred'] = all_preds
    metrics['y_proba'] = all_probs
    return metrics

def compute_metrics(y_true, y_pred, y_proba):
    acc = accuracy_score(y_true, y_pred)
    bal_acc = balanced_accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    macro_f1 = f1_score(y_true, y_pred, average='macro', zero_division=0)
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    roc_auc = roc_auc_score(y_true, y_proba)
    pr_auc = average_precision_score(y_true, y_proba)
    return {
        'accuracy': acc,
        'balanced_accuracy': bal_acc,
        'precision': prec,
        'recall': rec,
        'f1': f1,
        'macro_f1': macro_f1,
        'sensitivity': sensitivity,
        'specificity': specificity,
        'roc_auc': roc_auc,
        'pr_auc': pr_auc,
        'confusion_matrix': cm.tolist()
    }

def main():
    train_df = pd.read_csv(Path("data/splits/train.csv"))
    val_df = pd.read_csv(Path("data/splits/validation.csv"))
    test_df = pd.read_csv(Path("data/splits/test.csv"))

    preprocessor = build_preprocessor()

    train_dataset = MultimodalDataset(train_df, preprocessor, transform=train_transform,
                                      max_views=MAX_VIEWS, fit_preprocessor=True)
    # After fitting on train, use transform for val/test
    val_dataset = MultimodalDataset(val_df, preprocessor, transform=eval_transform,
                                    max_views=MAX_VIEWS, fit_preprocessor=False)
    test_dataset = MultimodalDataset(test_df, preprocessor, transform=eval_transform,
                                     max_views=MAX_VIEWS, fit_preprocessor=False)

    # Save preprocessor for reproducibility
    Path("results").mkdir(parents=True, exist_ok=True)
    joblib.dump(preprocessor, Path("results/tabular_preprocessor_multimodal.joblib"))

    y_train = train_df.loc[train_dataset.valid_indices, 'undernutrition_risk'].values
    pos_count = np.sum(y_train == 1)
    neg_count = np.sum(y_train == 0)
    pos_weight = neg_count / pos_count if pos_count > 0 else 1.0
    pos_weight_tensor = torch.tensor([pos_weight]).to(DEVICE)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight_tensor)

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

    tab_input_dim = train_dataset.tabular_features.shape[1]
    print(f"Tabular input dimension after preprocessing: {tab_input_dim}")
    model = MultimodalConcatModel(image_embed_dim=IMG_EMBED_DIM,
                                  tab_input_dim=tab_input_dim,
                                  tab_embed_dim=TAB_EMBED_DIM).to(DEVICE)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    best_val_roc = -1
    best_model_state = None
    patience = 5
    epochs_no_improve = 0

    print("Starting training...")
    for epoch in range(1, EPOCHS+1):
        train_loss = train_one_epoch(model, train_loader, optimizer, criterion, DEVICE)
        val_metrics = evaluate(model, val_loader, DEVICE)
        print(f"Epoch {epoch}/{EPOCHS} | Train Loss: {train_loss:.4f} | Val ROC-AUC: {val_metrics['roc_auc']:.4f} | Val Sens: {val_metrics['sensitivity']:.4f}")

        if val_metrics['roc_auc'] > best_val_roc:
            best_val_roc = val_metrics['roc_auc']
            best_model_state = copy.deepcopy(model.state_dict())
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= patience:
                print(f"Early stopping triggered after {epoch} epochs.")
                break

    if best_model_state:
        model.load_state_dict(best_model_state)

    val_metrics = evaluate(model, val_loader, DEVICE)
    test_metrics = evaluate(model, test_loader, DEVICE)

    print("\nValidation metrics:")
    for k, v in val_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            print(f"  {k}: {v}")
    print(f"  Confusion matrix:\n  {np.array(val_metrics['confusion_matrix'])}")
    print("\nTest metrics:")
    for k, v in test_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            print(f"  {k}: {v}")
    print(f"  Confusion matrix:\n  {np.array(test_metrics['confusion_matrix'])}")

    results = {
        'model': 'Multimodal concat (image + leakage-controlled tabular)',
        'feature_set': 'multimodal',
        'val_accuracy': val_metrics['accuracy'],
        'val_balanced_accuracy': val_metrics['balanced_accuracy'],
        'val_precision': val_metrics['precision'],
        'val_recall': val_metrics['recall'],
        'val_f1': val_metrics['f1'],
        'val_macro_f1': val_metrics['macro_f1'],
        'val_sensitivity': val_metrics['sensitivity'],
        'val_specificity': val_metrics['specificity'],
        'val_roc_auc': val_metrics['roc_auc'],
        'val_pr_auc': val_metrics['pr_auc'],
        'test_accuracy': test_metrics['accuracy'],
        'test_balanced_accuracy': test_metrics['balanced_accuracy'],
        'test_precision': test_metrics['precision'],
        'test_recall': test_metrics['recall'],
        'test_f1': test_metrics['f1'],
        'test_macro_f1': test_metrics['macro_f1'],
        'test_sensitivity': test_metrics['sensitivity'],
        'test_specificity': test_metrics['specificity'],
        'test_roc_auc': test_metrics['roc_auc'],
        'test_pr_auc': test_metrics['pr_auc'],
        'val_confusion_matrix': val_metrics['confusion_matrix'],
        'test_confusion_matrix': test_metrics['confusion_matrix'],
    }
    df_results = pd.DataFrame([results])
    out_path = Path("results/multimodal_concat.csv")
    df_results.to_csv(out_path, index=False)
    print(f"\nResults saved to {out_path}")

    report = []
    report.append("MULTIMODAL FUSION REPORT (SIMPLE CONCATENATION)")
    report.append("="*60)
    report.append(f"Image encoder: MobileNetV3-Small (pretrained) -> 128-dim")
    report.append(f"Multi-view aggregation: mean pooling over up to 4 views")
    report.append(f"Tabular features: age_months, gender, head_circumference_cm, waist_circumference_cm")
    report.append(f"Tabular encoder: MLP to 64-dim")
    report.append(f"Fusion: concatenate (192) -> 64 -> 1")
    report.append(f"Class weight (positive): {pos_weight:.4f}")
    report.append(f"Valid training samples: {len(train_dataset)}")
    report.append(f"Valid validation samples: {len(val_dataset)}")
    report.append(f"Valid test samples: {len(test_dataset)}")
    report.append("\nValidation metrics:")
    for k, v in val_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            report.append(f"  {k}: {v}")
    report.append(f"Validation confusion matrix:\n{np.array(val_metrics['confusion_matrix'])}")
    report.append(f"Validation classification report:\n{classification_report(val_metrics['y_true'], val_metrics['y_pred'], zero_division=0)}")
    report.append("\nTest metrics:")
    for k, v in test_metrics.items():
        if k not in ['y_true', 'y_pred', 'y_proba', 'confusion_matrix']:
            report.append(f"  {k}: {v}")
    report.append(f"Test confusion matrix:\n{np.array(test_metrics['confusion_matrix'])}")
    report.append(f"Test classification report:\n{classification_report(test_metrics['y_true'], test_metrics['y_pred'], zero_division=0)}")

    with open(Path("results/multimodal_concat_report.txt"), 'w') as f:
        f.write('\n'.join(report))
    print(f"Report saved to {Path('results/multimodal_concat_report.txt')}")

if __name__ == "__main__":
    main()
