#!/usr/bin/env python3
"""
Phase 11: Threshold tuning for cross-attention multimodal model.
Trains the model, saves probabilities, plots ROC/PR curves, and finds optimal threshold.
"""
import pandas as pd
import numpy as np
from pathlib import Path
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision import models
import torch.nn.functional as F
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, average_precision_score, confusion_matrix,
    classification_report, roc_curve, precision_recall_curve, auc
)
import copy, joblib
import matplotlib.pyplot as plt

torch.manual_seed(42)
np.random.seed(42)

RAW_DIR = Path("data/raw")
IMAGE_SIZE = 224
MAX_VIEWS = 4
BATCH_SIZE = 8
EPOCHS = 30
LEARNING_RATE = 1e-4
IMG_EMBED_DIM = 256
TAB_EMBED_DIM = 128
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

TABULAR_FEATURES = ['age_months', 'gender', 'head_circumference_cm', 'waist_circumference_cm']
NUMERIC_FEATURES = ['age_months', 'head_circumference_cm', 'waist_circumference_cm']
CATEGORICAL_FEATURES = ['gender']

# ---------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------
def build_preprocessor():
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, NUMERIC_FEATURES),
            ('cat', categorical_transformer, CATEGORICAL_FEATURES)
        ]
    )
    return preprocessor

# ---------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------
class MultimodalDataset(Dataset):
    def __init__(self, df, tabular_preprocessor, transform=None, max_views=4, fit_preprocessor=False):
        self.df = df.reset_index(drop=True)
        self.transform = transform
        self.max_views = max_views
        self.tabular_preprocessor = tabular_preprocessor
        self.valid_indices = []
        self.image_paths = []

        if fit_preprocessor:
            tabular_array = self.tabular_preprocessor.fit_transform(df[TABULAR_FEATURES])
        else:
            tabular_array = self.tabular_preprocessor.transform(df[TABULAR_FEATURES])
        self.tabular_features = tabular_array.astype(np.float32)

        for idx, row in self.df.iterrows():
            paths = []
            for col in ['image_1', 'image_2', 'image_3', 'image_4', 'image_5']:
                if col in row and pd.notna(row[col]):
                    rel_path = str(row[col]).strip().replace('/', '\\')
                    full_path = RAW_DIR / rel_path
                    if full_path.exists():
                        try:
                            with Image.open(full_path) as img:
                                img.verify()
                            paths.append(full_path)
                            if len(paths) >= max_views:
                                break
                        except Exception:
                            continue
            if len(paths) > 0:
                self.valid_indices.append(idx)
                self.image_paths.append(paths)
        print(f"Dataset: {len(self.valid_indices)} valid samples out of {len(df)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        row_idx = self.valid_indices[idx]
        row = self.df.iloc[row_idx]
        paths = self.image_paths[idx]
        images = []
        for p in paths:
            try:
                img = Image.open(p).convert('RGB')
            except Exception:
                img = Image.new('RGB', (IMAGE_SIZE, IMAGE_SIZE), (0, 0, 0))
            if self.transform:
                img = self.transform(img)
            images.append(img)
        while len(images) < self.max_views:
            images.append(torch.zeros_like(images[0]))
        image_tensor = torch.stack(images, dim=0)
        mask = torch.zeros(self.max_views, dtype=torch.float32)
        mask[:len(paths)] = 1.0
        tabular_tensor = torch.tensor(self.tabular_features[row_idx], dtype=torch.float32)
        label = torch.tensor(row['undernutrition_risk'], dtype=torch.float32)
        return image_tensor, mask, tabular_tensor, label

# ---------------------------------------------------------------------
# Transforms
# ---------------------------------------------------------------------
train_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomRotation(degrees=5),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
eval_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# ---------------------------------------------------------------------
# Model components
# ---------------------------------------------------------------------
class ImageEncoderResNet(nn.Module):
    def __init__(self, embed_dim=256):
        super().__init__()
        base = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
        self.features = nn.Sequential(*list(base.children())[:-1])
        self.projection = nn.Linear(512, embed_dim)
    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.projection(x)
        return x

class TabularEncoder(nn.Module):
    def __init__(self, input_dim, embed_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, embed_dim)
        )
    def forward(self, x):
        return self.net(x)

class AttentionPooling(nn.Module):
    def __init__(self, embed_dim):
        super().__init__()
        self.attn = nn.Linear(embed_dim, 1)
    def forward(self, embeddings, mask):
        scores = self.attn(embeddings).squeeze(-1)
        scores = scores.masked_fill(mask == 0, -1e9)
        weights = F.softmax(scores, dim=1).unsqueeze(-1)
        pooled = (embeddings * weights).sum(dim=1)
        return pooled

class CrossAttentionMultimodal(nn.Module):
    def __init__(self, tab_input_dim):
        super().__init__()
        self.image_encoder = ImageEncoderResNet(IMG_EMBED_DIM)
        self.pool = AttentionPooling(IMG_EMBED_DIM)
        self.tabular_encoder = TabularEncoder(tab_input_dim, TAB_EMBED_DIM)
        self.img_proj = nn.Linear(IMG_EMBED_DIM, 128)
        self.tab_proj = nn.Linear(TAB_EMBED_DIM, 128)
        self.attn = nn.MultiheadAttention(embed_dim=128, num_heads=4, batch_first=True)
        self.norm = nn.LayerNorm(128)
        self.fusion = nn.Sequential(
            nn.Linear(128 + TAB_EMBED_DIM, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    def forward(self, images, mask, tabular):
        B, V, C, H, W = images.shape
        flat = images.view(B * V, C, H, W)
        embeds = self.image_encoder(flat).view(B, V, -1)
        img_embed = self.pool(embeds, mask)
        tab_embed = self.tabular_encoder(tabular)
        q = self.img_proj(img_embed).unsqueeze(1)
        k = self.tab_proj(tab_embed).unsqueeze(1)
        attn_out, _ = self.attn(q, k, k)
        attn_out = self.norm(attn_out.squeeze(1))
        combined = torch.cat([attn_out, tab_embed], dim=1)
        return self.fusion(combined)

# ---------------------------------------------------------------------
# Training/evaluation
# ---------------------------------------------------------------------
def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    running_loss = 0.0
    for images, mask, tabular, labels in loader:
        images, mask, tabular, labels = images.to(device), mask.to(device), tabular.to(device), labels.to(device).unsqueeze(1)
        optimizer.zero_grad()
        logits = model(images, mask, tabular)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * images.size(0)
    return running_loss / len(loader.dataset)

def predict_proba(model, loader, device):
    model.eval()
    all_probs = []
    all_labels = []
    with torch.no_grad():
        for images, mask, tabular, labels in loader:
            images, mask, tabular, labels = images.to(device), mask.to(device), tabular.to(device), labels.to(device)
            logits = model(images, mask, tabular)
            probs = torch.sigmoid(logits).cpu().numpy().flatten()
            all_probs.extend(probs)
            all_labels.extend(labels.cpu().numpy())
    return np.array(all_probs), np.array(all_labels)

def main():
    # Load data
    train_df = pd.read_csv(Path("data/splits/train.csv"))
    val_df = pd.read_csv(Path("data/splits/validation.csv"))
    test_df = pd.read_csv(Path("data/splits/test.csv"))

    preprocessor = build_preprocessor()
    train_dataset = MultimodalDataset(train_df, preprocessor, transform=train_transform,
                                      max_views=MAX_VIEWS, fit_preprocessor=True)
    val_dataset = MultimodalDataset(val_df, preprocessor, transform=eval_transform,
                                    max_views=MAX_VIEWS, fit_preprocessor=False)
    test_dataset = MultimodalDataset(test_df, preprocessor, transform=eval_transform,
                                     max_views=MAX_VIEWS, fit_preprocessor=False)

    tab_input_dim = train_dataset.tabular_features.shape[1]
    print(f"Tabular input dimension: {tab_input_dim}")

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

    y_train = train_df.loc[train_dataset.valid_indices, 'undernutrition_risk'].values
    pos_count = np.sum(y_train == 1)
    neg_count = np.sum(y_train == 0)
    pos_weight = neg_count / pos_count if pos_count > 0 else 1.0
    pos_weight_tensor = torch.tensor([pos_weight]).to(DEVICE)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight_tensor)

    model = CrossAttentionMultimodal(tab_input_dim).to(DEVICE)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    best_val_roc = -1
    best_state = None
    patience = 7
    no_improve = 0

    print("Starting training...")
    for epoch in range(1, EPOCHS+1):
        train_loss = train_one_epoch(model, train_loader, optimizer, criterion, DEVICE)
        val_probs, val_labels = predict_proba(model, val_loader, DEVICE)
        val_roc = roc_auc_score(val_labels, val_probs)
        print(f"Epoch {epoch}/{EPOCHS} | Train Loss: {train_loss:.4f} | Val ROC-AUC: {val_roc:.4f}")

        if val_roc > best_val_roc:
            best_val_roc = val_roc
            best_state = copy.deepcopy(model.state_dict())
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= patience:
                print(f"Early stopping after {epoch} epochs.")
                break

    if best_state:
        model.load_state_dict(best_state)

    # Save model
    checkpoint_path = Path("checkpoints/best_cross_attention_model.pt")
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        'model_state_dict': model.state_dict(),
        'tab_input_dim': tab_input_dim,
        'pos_weight': pos_weight
    }, checkpoint_path)
    print(f"Model saved to {checkpoint_path}")

    # Get probabilities for all splits
    train_probs, train_labels = predict_proba(model, train_loader, DEVICE)
    val_probs, val_labels = predict_proba(model, val_loader, DEVICE)
    test_probs, test_labels = predict_proba(model, test_loader, DEVICE)

    # Save probabilities
    pd.DataFrame({'label': val_labels, 'prob': val_probs}).to_csv("results/val_probs.csv", index=False)
    pd.DataFrame({'label': test_labels, 'prob': test_probs}).to_csv("results/test_probs.csv", index=False)

    # ROC and PR curves
    fpr, tpr, thresholds_roc = roc_curve(val_labels, val_probs)
    roc_auc_val = auc(fpr, tpr)
    precision, recall, thresholds_pr = precision_recall_curve(val_labels, val_probs)
    pr_auc_val = average_precision_score(val_labels, val_probs)

    # Youden's J to find optimal threshold
    j_scores = tpr - fpr
    optimal_idx = np.argmax(j_scores)
    optimal_threshold = thresholds_roc[optimal_idx]
    print(f"Optimal threshold (Youden) on validation: {optimal_threshold:.4f}")

    # Apply optimal threshold to test
    test_preds_opt = (test_probs >= optimal_threshold).astype(int)
    test_metrics = {
        'accuracy': accuracy_score(test_labels, test_preds_opt),
        'balanced_accuracy': balanced_accuracy_score(test_labels, test_preds_opt),
        'precision': precision_score(test_labels, test_preds_opt, zero_division=0),
        'recall': recall_score(test_labels, test_preds_opt, zero_division=0),
        'f1': f1_score(test_labels, test_preds_opt, zero_division=0),
        'sensitivity': recall_score(test_labels, test_preds_opt, zero_division=0),
        'specificity': recall_score(test_labels, test_preds_opt, pos_label=0, zero_division=0),
        'roc_auc': roc_auc_score(test_labels, test_probs),
        'pr_auc': average_precision_score(test_labels, test_probs),
        'confusion_matrix': confusion_matrix(test_labels, test_preds_opt).tolist()
    }
    print("\nTest metrics with optimal threshold:")
    for k, v in test_metrics.items():
        print(f"  {k}: {v}")

    # Also compute default threshold (0.5) metrics for comparison
    test_preds_default = (test_probs >= 0.5).astype(int)
    default_metrics = {
        'accuracy': accuracy_score(test_labels, test_preds_default),
        'sensitivity': recall_score(test_labels, test_preds_default, zero_division=0),
        'specificity': recall_score(test_labels, test_preds_default, pos_label=0, zero_division=0),
        'f1': f1_score(test_labels, test_preds_default, zero_division=0)
    }
    print("\nTest metrics with default 0.5 threshold:")
    for k, v in default_metrics.items():
        print(f"  {k}: {v}")

    # Save metrics and threshold info
    with open("results/threshold_tuning_report.txt", 'w') as f:
        f.write("CROSS-ATTENTION MULTIMODAL THRESHOLD TUNING\n")
        f.write("="*60 + "\n")
        f.write(f"Optimal threshold (Youden's J) on validation: {optimal_threshold:.4f}\n")
        f.write(f"Validation ROC-AUC: {roc_auc_val:.4f}\n")
        f.write(f"Validation PR-AUC: {pr_auc_val:.4f}\n\n")
        f.write("Test metrics with optimal threshold:\n")
        for k, v in test_metrics.items():
            f.write(f"  {k}: {v}\n")
        f.write("\nTest metrics with default 0.5 threshold:\n")
        for k, v in default_metrics.items():
            f.write(f"  {k}: {v}\n")

    # Plot ROC curves
    plt.figure(figsize=(6,5))
    fpr_test, tpr_test, _ = roc_curve(test_labels, test_probs)
    plt.plot(fpr, tpr, label=f'Validation ROC (AUC = {roc_auc_val:.2f})')
    plt.plot(fpr_test, tpr_test, label=f'Test ROC (AUC = {roc_auc_score(test_labels, test_probs):.2f})')
    plt.plot([0,1],[0,1],'k--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curves - Cross-Attention Multimodal')
    plt.legend()
    plt.savefig("results/roc_curve.png", dpi=300, bbox_inches='tight')
    plt.close()

    # Plot PR curves
    plt.figure(figsize=(6,5))
    precision_test, recall_test, _ = precision_recall_curve(test_labels, test_probs)
    plt.plot(recall, precision, label=f'Validation PR (AUC = {pr_auc_val:.2f})')
    plt.plot(recall_test, precision_test, label=f'Test PR (AUC = {average_precision_score(test_labels, test_probs):.2f})')
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curves - Cross-Attention Multimodal')
    plt.legend()
    plt.savefig("results/pr_curve.png", dpi=300, bbox_inches='tight')
    plt.close()

    print("\nPlots saved to results/roc_curve.png and results/pr_curve.png")
    print("Report saved to results/threshold_tuning_report.txt")

if __name__ == "__main__":
    main()
