#!/usr/bin/env python3
"""
Phase 10: Advanced ablation study
Compares image-only, tabular-only, and cross-attention multimodal
using ResNet18 encoder and attention pooling.
"""
import pandas as pd
import numpy as np
from pathlib import Path
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision import models
import torch.nn.functional as F
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, average_precision_score, confusion_matrix,
    classification_report
)
import copy, joblib

torch.manual_seed(42)
np.random.seed(42)

RAW_DIR = Path("data/raw")
IMAGE_SIZE = 224
MAX_VIEWS = 4
BATCH_SIZE = 8
EPOCHS = 30
LEARNING_RATE = 1e-4
IMG_EMBED_DIM = 256
TAB_EMBED_DIM = 128
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

TABULAR_FEATURES = ['age_months', 'gender', 'head_circumference_cm', 'waist_circumference_cm']
NUMERIC_FEATURES = ['age_months', 'head_circumference_cm', 'waist_circumference_cm']
CATEGORICAL_FEATURES = ['gender']

def build_preprocessor():
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, NUMERIC_FEATURES),
            ('cat', categorical_transformer, CATEGORICAL_FEATURES)
        ]
    )
    return preprocessor

class AblationDataset(Dataset):
    def __init__(self, df, tabular_preprocessor, transform=None, max_views=4, fit_preprocessor=False):
        self.df = df.reset_index(drop=True)
        self.transform = transform
        self.max_views = max_views
        self.tabular_preprocessor = tabular_preprocessor
        self.valid_indices = []
        self.image_paths = []

        if fit_preprocessor:
            tabular_array = self.tabular_preprocessor.fit_transform(df[TABULAR_FEATURES])
        else:
            tabular_array = self.tabular_preprocessor.transform(df[TABULAR_FEATURES])
        self.tabular_features = tabular_array.astype(np.float32)

        for idx, row in self.df.iterrows():
            paths = []
            for col in ['image_1', 'image_2', 'image_3', 'image_4', 'image_5']:
                if col in row and pd.notna(row[col]):
                    rel_path = str(row[col]).strip().replace('/', '\\')
                    full_path = RAW_DIR / rel_path
                    if full_path.exists():
                        try:
                            with Image.open(full_path) as img:
                                img.verify()
                            paths.append(full_path)
                            if len(paths) >= max_views:
                                break
                        except Exception:
                            continue
            if len(paths) > 0:
                self.valid_indices.append(idx)
                self.image_paths.append(paths)
        print(f"Dataset: {len(self.valid_indices)} valid samples out of {len(df)}")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        row_idx = self.valid_indices[idx]
        row = self.df.iloc[row_idx]
        paths = self.image_paths[idx]
        images = []
        for p in paths:
            try:
                img = Image.open(p).convert('RGB')
            except Exception:
                img = Image.new('RGB', (IMAGE_SIZE, IMAGE_SIZE), (0, 0, 0))
            if self.transform:
                img = self.transform(img)
            images.append(img)
        while len(images) < self.max_views:
            images.append(torch.zeros_like(images[0]))
        image_tensor = torch.stack(images, dim=0)
        mask = torch.zeros(self.max_views, dtype=torch.float32)
        mask[:len(paths)] = 1.0
        tabular_tensor = torch.tensor(self.tabular_features[row_idx], dtype=torch.float32)
        label = torch.tensor(row['undernutrition_risk'], dtype=torch.float32)
        return image_tensor, mask, tabular_tensor, label

train_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomRotation(degrees=5),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
eval_transform = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

class ImageEncoderResNet(nn.Module):
    def __init__(self, embed_dim=256):
        super().__init__()
        base = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
        self.features = nn.Sequential(*list(base.children())[:-1])
        self.projection = nn.Linear(512, embed_dim)
    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.projection(x)
        return x

class TabularEncoder(nn.Module):
    def __init__(self, input_dim, embed_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, embed_dim)
        )
    def forward(self, x):
        return self.net(x)

class AttentionPooling(nn.Module):
    def __init__(self, embed_dim):
        super().__init__()
        self.attn = nn.Linear(embed_dim, 1)
    def forward(self, embeddings, mask):
        scores = self.attn(embeddings).squeeze(-1)
        scores = scores.masked_fill(mask == 0, -1e9)
        weights = F.softmax(scores, dim=1).unsqueeze(-1)
        pooled = (embeddings * weights).sum(dim=1)
        return pooled

class ImageOnlyModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = ImageEncoderResNet(IMG_EMBED_DIM)
        self.pool = AttentionPooling(IMG_EMBED_DIM)
        self.classifier = nn.Sequential(
            nn.Linear(IMG_EMBED_DIM, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    def forward(self, images, mask, tabular=None):
        B, V, C, H, W = images.shape
        flat = images.view(B * V, C, H, W)
        embeds = self.encoder(flat).view(B, V, -1)
        pooled = self.pool(embeds, mask)
        return self.classifier(pooled)

class TabularOnlyModel(nn.Module):
    def __init__(self, tab_input_dim):
        super().__init__()
        self.encoder = TabularEncoder(tab_input_dim, TAB_EMBED_DIM)
        self.classifier = nn.Sequential(
            nn.Linear(TAB_EMBED_DIM, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    def forward(self, images, mask, tabular):
        tab_embed = self.encoder(tabular)
        return self.classifier(tab_embed)

class CrossAttentionMultimodal(nn.Module):
    def __init__(self, tab_input_dim):
        super().__init__()
        self.image_encoder = ImageEncoderResNet(IMG_EMBED_DIM)
        self.pool = AttentionPooling(IMG_EMBED_DIM)
        self.tabular_encoder = TabularEncoder(tab_input_dim, TAB_EMBED_DIM)
        self.img_proj = nn.Linear(IMG_EMBED_DIM, 128)
        self.tab_proj = nn.Linear(TAB_EMBED_DIM, 128)
        self.attn = nn.MultiheadAttention(embed_dim=128, num_heads=4, batch_first=True)
        self.norm = nn.LayerNorm(128)
        self.fusion = nn.Sequential(
            nn.Linear(128 + TAB_EMBED_DIM, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    def forward(self, images, mask, tabular):
        B, V, C, H, W = images.shape
        flat = images.view(B * V, C, H, W)
        embeds = self.image_encoder(flat).view(B, V, -1)
        img_embed = self.pool(embeds, mask)
        tab_embed = self.tabular_encoder(tabular)
        q = self.img_proj(img_embed).unsqueeze(1)
        k = self.tab_proj(tab_embed).unsqueeze(1)
        attn_out, _ = self.attn(q, k, k)
        attn_out = self.norm(attn_out.squeeze(1))
        combined = torch.cat([attn_out, tab_embed], dim=1)
        return self.fusion(combined)

def train_one_epoch(model, loader, optimizer, criterion, device, modality):
    model.train()
    running_loss = 0.0
    for batch in loader:
        images, mask, tabular, labels = batch
        images, mask, tabular, labels = images.to(device), mask.to(device), tabular.to(device), labels.to(device).unsqueeze(1)
        optimizer.zero_grad()
        if modality == 'image':
            logits = model(images, mask)
        else:
            logits = model(images, mask, tabular)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * images.size(0)
    return running_loss / len(loader.dataset)

def evaluate(model, loader, device, modality):
    model.eval()
    all_preds, all_labels, all_probs = [], [], []
    with torch.no_grad():
        for batch in loader:
            images, mask, tabular, labels = batch
            images, mask, tabular, labels = images.to(device), mask.to(device), tabular.to(device), labels.to(device)
            if modality == 'image':
                logits = model(images, mask)
            else:
                logits = model(images, mask, tabular)
            probs = torch.sigmoid(logits).cpu().numpy().flatten()
            preds = (probs >= 0.5).astype(int)
            all_probs.extend(probs)
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())
    metrics = compute_metrics(all_labels, all_preds, all_probs)
    metrics['y_true'] = all_labels
    metrics['y_pred'] = all_preds
    metrics['y_proba'] = all_probs
    return metrics

def compute_metrics(y_true, y_pred, y_proba):
    acc = accuracy_score(y_true, y_pred)
    bal_acc = balanced_accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    macro_f1 = f1_score(y_true, y_pred, average='macro', zero_division=0)
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    roc_auc = roc_auc_score(y_true, y_proba)
    pr_auc = average_precision_score(y_true, y_proba)
    return {
        'accuracy': acc, 'balanced_accuracy': bal_acc,
        'precision': prec, 'recall': rec, 'f1': f1, 'macro_f1': macro_f1,
        'sensitivity': sensitivity, 'specificity': specificity,
        'roc_auc': roc_auc, 'pr_auc': pr_auc, 'confusion_matrix': cm.tolist()
    }

def main():
    train_df = pd.read_csv(Path("data/splits/train.csv"))
    val_df = pd.read_csv(Path("data/splits/validation.csv"))
    test_df = pd.read_csv(Path("data/splits/test.csv"))

    preprocessor = build_preprocessor()
    train_dataset = AblationDataset(train_df, preprocessor, transform=train_transform,
                                    max_views=MAX_VIEWS, fit_preprocessor=True)
    val_dataset = AblationDataset(val_df, preprocessor, transform=eval_transform,
                                  max_views=MAX_VIEWS, fit_preprocessor=False)
    test_dataset = AblationDataset(test_df, preprocessor, transform=eval_transform,
                                   max_views=MAX_VIEWS, fit_preprocessor=False)

    tab_input_dim = train_dataset.tabular_features.shape[1]
    print(f"Tabular input dimension: {tab_input_dim}")

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

    y_train = train_df.loc[train_dataset.valid_indices, 'undernutrition_risk'].values
    pos_count = np.sum(y_train == 1)
    neg_count = np.sum(y_train == 0)
    pos_weight = neg_count / pos_count if pos_count > 0 else 1.0
    pos_weight_tensor = torch.tensor([pos_weight]).to(DEVICE)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight_tensor)

    models = {
        'image_only': (ImageOnlyModel().to(DEVICE), 'image'),
        'tabular_only': (TabularOnlyModel(tab_input_dim).to(DEVICE), 'tabular'),
        'multimodal_cross_attention': (CrossAttentionMultimodal(tab_input_dim).to(DEVICE), 'multimodal')
    }

    all_results = []
    report_lines = ["ADVANCED ABLATION STUDY", "="*80]

    for name, (model, modality) in models.items():
        print(f"\n=== Training {name} ===")
        optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
        best_val_roc = -1
        best_state = None
        patience = 7
        no_improve = 0

        for epoch in range(1, EPOCHS+1):
            train_loss = train_one_epoch(model, train_loader, optimizer, criterion, DEVICE, modality)
            val_metrics = evaluate(model, val_loader, DEVICE, modality)
            print(f"Epoch {epoch}/{EPOCHS} | Train Loss: {train_loss:.4f} | Val ROC-AUC: {val_metrics['roc_auc']:.4f} | Val Sens: {val_metrics['sensitivity']:.4f}")

            if val_metrics['roc_auc'] > best_val_roc:
                best_val_roc = val_metrics['roc_auc']
                best_state = copy.deepcopy(model.state_dict())
                no_improve = 0
            else:
                no_improve += 1
                if no_improve >= patience:
                    print(f"Early stopping after {epoch} epochs.")
                    break

        if best_state:
            model.load_state_dict(best_state)

        val_metrics = evaluate(model, val_loader, DEVICE, modality)
        test_metrics = evaluate(model, test_loader, DEVICE, modality)

        results = {
            'model': name,
            'val_roc_auc': val_metrics['roc_auc'],
            'val_sensitivity': val_metrics['sensitivity'],
            'val_specificity': val_metrics['specificity'],
            'test_roc_auc': test_metrics['roc_auc'],
            'test_sensitivity': test_metrics['sensitivity'],
            'test_specificity': test_metrics['specificity'],
            'val_confusion_matrix': val_metrics['confusion_matrix'],
            'test_confusion_matrix': test_metrics['confusion_matrix'],
        }
        all_results.append(results)
        report_lines.append(f"\nModel: {name}")
        report_lines.append(f"Validation ROC-AUC: {val_metrics['roc_auc']:.4f}, Sens: {val_metrics['sensitivity']:.4f}, Spec: {val_metrics['specificity']:.4f}")
        report_lines.append(f"Test ROC-AUC: {test_metrics['roc_auc']:.4f}, Sens: {test_metrics['sensitivity']:.4f}, Spec: {test_metrics['specificity']:.4f}")
        report_lines.append(f"Validation CM:\n{np.array(val_metrics['confusion_matrix'])}")
        report_lines.append(f"Test CM:\n{np.array(test_metrics['confusion_matrix'])}")

    df_results = pd.DataFrame(all_results)
    out_csv = Path("results/advanced_ablation.csv")
    df_results.to_csv(out_csv, index=False)
    print(f"\nResults saved to {out_csv}")

    with open(Path("results/advanced_ablation_report.txt"), 'w') as f:
        f.write('\n'.join(report_lines))
    print(f"Report saved to {Path('results/advanced_ablation_report.txt')}")

    print("\nFinal comparison (test metrics):")
    print(df_results[['model', 'test_roc_auc', 'test_sensitivity', 'test_specificity']].to_string(index=False))

if __name__ == "__main__":
    main()
