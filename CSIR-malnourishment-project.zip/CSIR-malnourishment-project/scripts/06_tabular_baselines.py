#!/usr/bin/env python3
"""
Phase 5: Tabular baselines (classical ML models)
Trains Logistic Regression, Random Forest, Gradient Boosting, and MLP
on full and leakage-controlled tabular features.
Evaluates on validation and test sets; saves metrics.
"""
import pandas as pd
import numpy as np
import json
from pathlib import Path
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, average_precision_score, confusion_matrix,
    classification_report
)

# ---------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------
def get_feature_sets():
    """Load feature set definitions from JSON."""
    with open(Path("data/processed/feature_sets.json"), 'r') as f:
        feature_sets = json.load(f)
    return feature_sets

def build_preprocessor(numeric_features, categorical_features):
    """Create a ColumnTransformer for preprocessing."""
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore'))
    ])
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numeric_features),
            ('cat', categorical_transformer, categorical_features)
        ]
    )
    return preprocessor

def evaluate_model(model, X_train, y_train, X_val, y_val, X_test, y_test):
    """Train model and compute evaluation metrics on val/test."""
    model.fit(X_train, y_train)
    
    results = {}
    for split_name, X, y in [('val', X_val, y_val), ('test', X_test, y_test)]:
        y_pred = model.predict(X)
        y_proba = model.predict_proba(X)[:, 1] if hasattr(model, "predict_proba") else None
        
        acc = accuracy_score(y, y_pred)
        bal_acc = balanced_accuracy_score(y, y_pred)
        prec = precision_score(y, y_pred, zero_division=0)
        rec = recall_score(y, y_pred, zero_division=0)
        f1 = f1_score(y, y_pred, zero_division=0)
        macro_f1 = f1_score(y, y_pred, average='macro', zero_division=0)
        cm = confusion_matrix(y, y_pred)
        tn, fp, fn, tp = cm.ravel()
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else np.nan
        specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
        
        if y_proba is not None:
            roc_auc = roc_auc_score(y, y_proba)
            pr_auc = average_precision_score(y, y_proba)
        else:
            roc_auc = np.nan
            pr_auc = np.nan
        
        results[f'{split_name}_accuracy'] = acc
        results[f'{split_name}_balanced_accuracy'] = bal_acc
        results[f'{split_name}_precision'] = prec
        results[f'{split_name}_recall'] = rec
        results[f'{split_name}_f1'] = f1
        results[f'{split_name}_macro_f1'] = macro_f1
        results[f'{split_name}_sensitivity'] = sensitivity
        results[f'{split_name}_specificity'] = specificity
        results[f'{split_name}_roc_auc'] = roc_auc
        results[f'{split_name}_pr_auc'] = pr_auc
        results[f'{split_name}_confusion_matrix'] = cm.tolist()
    
    return results

def main():
    # Load splits
    train_df = pd.read_csv(Path("data/splits/train.csv"))
    val_df = pd.read_csv(Path("data/splits/validation.csv"))
    test_df = pd.read_csv(Path("data/splits/test.csv"))
    
    # Load feature sets
    feature_sets = get_feature_sets()
    full_features = feature_sets['full_tabular']
    leakage_features = feature_sets['leakage_controlled_tabular']
    
    # Identify numeric/categorical columns
    # Gender is categorical; rest are numeric
    all_numeric = ['age_months', 'height_cm', 'weight_g', 'head_circumference_cm', 'waist_circumference_cm']
    categorical = ['gender']
    
    # Define feature set configs
    configs = [
        ('full_tabular', full_features),
        ('leakage_controlled_tabular', leakage_features)
    ]
    
    models = {
        'Logistic Regression': LogisticRegression(class_weight='balanced', max_iter=1000, random_state=42),
        'Random Forest': RandomForestClassifier(class_weight='balanced', random_state=42),
        'Gradient Boosting': GradientBoostingClassifier(random_state=42),
        'MLP': MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=1000, random_state=42)
    }
    
    all_results = []
    report_lines = []
    report_lines.append("TABULAR BASELINE RESULTS")
    report_lines.append("=" * 80)
    
    for feature_set_name, feature_list in configs:
        print(f"\n=== Feature set: {feature_set_name} ===")
        print(f"Features: {feature_list}")
        
        # Separate features and target
        X_train = train_df[feature_list]
        y_train = train_df['undernutrition_risk']
        X_val = val_df[feature_list]
        y_val = val_df['undernutrition_risk']
        X_test = test_df[feature_list]
        y_test = test_df['undernutrition_risk']
        
        # Determine numeric features from current feature list
        numeric_features = [f for f in feature_list if f in all_numeric]
        categorical_features = [f for f in feature_list if f in categorical]
        
        preprocessor = build_preprocessor(numeric_features, categorical_features)
        
        for model_name, model in models.items():
            print(f"  Training {model_name}...")
            pipeline = Pipeline(steps=[('preprocessor', preprocessor), ('classifier', model)])
            res = evaluate_model(pipeline, X_train, y_train, X_val, y_val, X_test, y_test)
            res['feature_set'] = feature_set_name
            res['model'] = model_name
            all_results.append(res)
            
            report_lines.append(f"\nModel: {model_name} | Feature set: {feature_set_name}")
            for k, v in res.items():
                if 'confusion' not in k:
                    report_lines.append(f"  {k}: {v}")
            report_lines.append(f"  Validation confusion matrix:\n  {np.array(res['val_confusion_matrix'])}")
            report_lines.append(f"  Test confusion matrix:\n  {np.array(res['test_confusion_matrix'])}")
            report_lines.append(f"  Validation classification report:\n{classification_report(y_val, pipeline.predict(X_val), zero_division=0)}")
            report_lines.append(f"  Test classification report:\n{classification_report(y_test, pipeline.predict(X_test), zero_division=0)}")
    
    # Save results DataFrame
    results_df = pd.DataFrame(all_results)
    results_path = Path("results/tabular_baselines.csv")
    results_path.parent.mkdir(parents=True, exist_ok=True)
    results_df.to_csv(results_path, index=False)
    print(f"\nResults saved to {results_path}")
    
    # Save report
    report_path = Path("results/tabular_baselines_report.txt")
    with open(report_path, 'w') as f:
        f.write('\n'.join(report_lines))
    print(f"Report saved to {report_path}")
    
    # Print condensed results
    print("\nCondensed results (validation metrics):")
    print(results_df[['model', 'feature_set', 'val_accuracy', 'val_balanced_accuracy',
                      'val_sensitivity', 'val_specificity', 'val_f1', 'val_roc_auc']].to_string(index=False))

if __name__ == "__main__":
    main()
