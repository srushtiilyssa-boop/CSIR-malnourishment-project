"""
Tabular feature encoding module.
"""
import torch
import torch.nn as nn


class TabularEncoder(nn.Module):
    """
    MLP-based encoder for tabular features.
    
    Args:
        input_dim (int): Input dimension (after preprocessing).
        embed_dim (int): Embedding dimension (default: 128).
    """
    def __init__(self, input_dim, embed_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, embed_dim)
        )

    def forward(self, x):
        """
        Args:
            x: Tabular features (B, input_dim)
        Returns:
            Embeddings (B, embed_dim)
        """
        return self.net(x)
