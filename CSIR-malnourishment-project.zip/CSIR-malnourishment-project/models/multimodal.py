"""
Multimodal fusion modules combining image and tabular modalities.
"""
import torch
import torch.nn as nn
from .image_encoder import ImageEncoderResNet, AttentionPooling
from .tabular_encoder import TabularEncoder


class ConcatFusion(nn.Module):
    """Simple concatenation fusion."""
    def __init__(self, img_embed_dim, tab_embed_dim):
        super().__init__()
        self.fusion = nn.Sequential(
            nn.Linear(img_embed_dim + tab_embed_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    
    def forward(self, img_embed, tab_embed):
        combined = torch.cat([img_embed, tab_embed], dim=1)
        return self.fusion(combined)


class GatedFusion(nn.Module):
    """Gated fusion with learned importance weights."""
    def __init__(self, img_embed_dim, tab_embed_dim):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(img_embed_dim + tab_embed_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 2),
            nn.Sigmoid()
        )
        self.fusion = nn.Sequential(
            nn.Linear(img_embed_dim + tab_embed_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    
    def forward(self, img_embed, tab_embed):
        combined = torch.cat([img_embed, tab_embed], dim=1)
        g = self.gate(combined)  # (B, 2)
        weighted_img = img_embed * g[:, 0].unsqueeze(1)
        weighted_tab = tab_embed * g[:, 1].unsqueeze(1)
        combined_weighted = torch.cat([weighted_img, weighted_tab], dim=1)
        return self.fusion(combined_weighted)


class CrossAttentionFusion(nn.Module):
    """Cross-attention based fusion between image and tabular modalities."""
    def __init__(self, img_embed_dim, tab_embed_dim):
        super().__init__()
        self.img_proj = nn.Linear(img_embed_dim, 128)
        self.tab_proj = nn.Linear(tab_embed_dim, 128)
        self.attn = nn.MultiheadAttention(embed_dim=128, num_heads=4, batch_first=True)
        self.norm = nn.LayerNorm(128)
        self.fusion = nn.Sequential(
            nn.Linear(128 + tab_embed_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    
    def forward(self, img_embed, tab_embed):
        q = self.img_proj(img_embed).unsqueeze(1)  # (B, 1, 128)
        k = self.tab_proj(tab_embed).unsqueeze(1)  # (B, 1, 128)
        attn_out, _ = self.attn(q, k, k)
        attn_out = self.norm(attn_out.squeeze(1))
        combined = torch.cat([attn_out, tab_embed], dim=1)
        return self.fusion(combined)


class CrossAttentionMultimodal(nn.Module):
    """
    Full cross-attention multimodal model.
    Combines ResNet18 image encoder with attention pooling and tabular encoder.
    
    Args:
        tab_input_dim (int): Tabular input dimension (after preprocessing).
        img_embed_dim (int): Image embedding dimension (default: 256).
        tab_embed_dim (int): Tabular embedding dimension (default: 128).
    """
    def __init__(self, tab_input_dim, img_embed_dim=256, tab_embed_dim=128):
        super().__init__()
        self.image_encoder = ImageEncoderResNet(img_embed_dim)
        self.pool = AttentionPooling(img_embed_dim)
        self.tabular_encoder = TabularEncoder(tab_input_dim, tab_embed_dim)
        self.img_proj = nn.Linear(img_embed_dim, 128)
        self.tab_proj = nn.Linear(tab_embed_dim, 128)
        self.attn = nn.MultiheadAttention(embed_dim=128, num_heads=4, batch_first=True)
        self.norm = nn.LayerNorm(128)
        self.fusion = nn.Sequential(
            nn.Linear(128 + tab_embed_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )

    def forward(self, images, mask, tabular):
        """
        Args:
            images: Multi-view images (B, V, 3, 224, 224)
            mask: Attention mask (B, V)
            tabular: Tabular features (B, tab_input_dim)
        Returns:
            Logits (B, 1)
        """
        # Image encoding and pooling
        B, V, C, H, W = images.shape
        flat = images.view(B * V, C, H, W)
        embeds = self.image_encoder(flat).view(B, V, -1)
        img_embed = self.pool(embeds, mask)
        
        # Tabular encoding
        tab_embed = self.tabular_encoder(tabular)
        
        # Cross-attention fusion
        q = self.img_proj(img_embed).unsqueeze(1)
        k = self.tab_proj(tab_embed).unsqueeze(1)
        attn_out, _ = self.attn(q, k, k)
        attn_out = self.norm(attn_out.squeeze(1))
        combined = torch.cat([attn_out, tab_embed], dim=1)
        
        return self.fusion(combined)
