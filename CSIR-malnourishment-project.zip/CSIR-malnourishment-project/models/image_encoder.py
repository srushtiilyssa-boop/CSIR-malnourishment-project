"""
Image encoding and multi-view aggregation modules.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models


class ImageEncoderResNet(nn.Module):
    """
    ResNet18-based image encoder with projection to embedding dimension.
    
    Args:
        embed_dim (int): Embedding dimension (default: 256).
    """
    def __init__(self, embed_dim=256):
        super().__init__()
        base = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
        self.features = nn.Sequential(*list(base.children())[:-1])
        self.projection = nn.Linear(512, embed_dim)

    def forward(self, x):
        """
        Args:
            x: Batch of images (B, 3, 224, 224)
        Returns:
            Embeddings (B, embed_dim)
        """
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.projection(x)
        return x


class AttentionPooling(nn.Module):
    """
    Attention-based pooling for multi-view image aggregation.
    
    Args:
        embed_dim (int): Embedding dimension.
    """
    def __init__(self, embed_dim):
        super().__init__()
        self.attn = nn.Linear(embed_dim, 1)

    def forward(self, embeddings, mask):
        """
        Args:
            embeddings: Multi-view embeddings (B, V, embed_dim)
            mask: Attention mask (B, V) where 1=valid, 0=padded
        Returns:
            Pooled embedding (B, embed_dim)
        """
        scores = self.attn(embeddings).squeeze(-1)  # (B, V)
        scores = scores.masked_fill(mask == 0, -1e9)
        weights = F.softmax(scores, dim=1).unsqueeze(-1)  # (B, V, 1)
        pooled = (embeddings * weights).sum(dim=1)  # (B, embed_dim)
        return pooled
